/*
 *  FBtoCPrefix.h
 *  
 *  rp:20090207
 *  Identical with FBtoC_Prefix_gcc.h except for name
 */

#include "FBtoC.h"
