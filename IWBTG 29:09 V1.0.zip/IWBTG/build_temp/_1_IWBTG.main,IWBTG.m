#include "_1_IWBTG.main,IWBTG.h"
#include "ArrayIndices.h"

#include "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//       translated globals and fns              //
///////////////////////////////////////////////////
 


Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
{
  GraphicsImportComponent gi; 
  ComponentResult   result; 
  PicHandle         pictH; 
  pictH = NULL; 
  CFURLRef          url; 
  FSRef             fsRef; 
  FSSpec            fsSpec; 
  OSErr             err; 
  FBBoolean         success; 
  url = CFBundleCopyResourceURL( CFBundleGetMainBundle(), imageName, NULL, NULL ); 
  if ( url ) 
  { 
  success = CFURLGetFSRef( url, (void*)&fsRef ); 
  CFRelease( url ); 
  if ( success ) 
  { 
  err = FSGetCatalogInfo( (void*)&fsRef, 0, NULL, NULL, &fsSpec, NULL ); 
  if ( err == noErr ) 
  { 
  err = GetGraphicsImporterForFile( (void*)&fsSpec, (void*)&gi ); 
  if ( err == noErr ) 
  { 
  result = GraphicsImportGetAsPicture( gi, (void*)&pictH ); 
  result = GraphicsImportGetBoundsRect( gi, imageRect ); 
  err = CloseComponent( gi ); 
  } 
  } 
  } 
  } 
  return (Handle)pictH; 
}  
  
Handle            pictH; 
Rect              r; 
Str255            lastDir; 
short             hitX1; 
short             hitY1; 
short             hitX2; 
short             hitY2; 
short             distanceCheck; 
short             randInt; 
Str255            inkey; 
short             heightCounter; 
Str255            inkeyFill; 
Str255            upDown; 
Str255            game; 
short             score; 
short             loopCycle; 
Str255            scoreCheck; 
Str255            leftRight; 
short             jumpNo; 
short             tempJump; 
short             index1; 
short             index2; 
Str255            blocks[26][20]; 
Str255            object; 
CFURLRef          fPath; 
short             bul1X; 
short             bul1Y; 
short             bul2X; 
short             bul2Y; 
short             bul3X; 
short             bul3Y; 
Str255            bulDir1; 
Str255            bulDir2; 
Str255            bulDir3; 
Str255            bul1Flag; 
Str255            hitBrickX; 
Str255            hitBrickY; 
Str255            prevCheck; 
short             replacementBlockX1; 
short             replacementBlockY1; 
short             replacementBlockX2; 
short             replacementBlockY2; 

///////////////////////////////////////////////////
//            translated main code               //
///////////////////////////////////////////////////
int main( int argc, const char * argv[] ) 
{ 
  InitFBGlobals(); 
  FBWindow( 1, CFSTR( "IWBTG" ), (struct CGRect){ { (double)0, (double)0 }, { ((double)600)- ((double)0), ((double)456)- ((double)0) } }, 0, &(int){-1} ); 
  fPath = (void*)OSpanelOpen( 0, CFSTR( "Select a file" ), CFSTR( "txt" ), CFSTR( "Open" ), NULL ); 
  FBOpenInput( 1, (void*)2, &fPath, 256, false ); 
 
  for ( index2  = 1; index2 <= 19; index2++ )  { 
 
  for ( index1  = 1; index1 <= 25; index1++ )  { 
  FBReadString( 1, (char*)&object, 5 );  
  TRUNCATE( (void*)&object ); 
  PSstrcpy( blocks[ChkBounds( index1, 25, 117, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 117, CFSTR("IWBTG.main") )], object ); 
  } 
  } 
  FBClose( 1 ); 
 
  for ( index2  = 1; index2 <= 19; index2++ )  { 
 
  for ( index1  = 1; index1 <= 25; index1++ )  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), blocks[ChkBounds( index1, 25, 125, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 125, CFSTR("IWBTG.main") )] )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pbrick" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\psave-" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save RED.png" ), (void*)&r ); 
  } 
 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pair--" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( index1, 25, 137, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 137, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBPicture( &(Rect){(index2 - 1) * 24, (index1 - 1) * 24, ((index2 - 1) * 24) + 25, ((index1 - 1) * 24) + 25}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  } 
  } 
  hitX1 = 24; 
  hitX2 = 48; 
  hitY1 = 48; 
  hitY2 = 72; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
 
  do 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), upDown )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pup" ) ) == 0 ) 
  { 
  if ( jumpNo == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 170, CFSTR("IWBTG.main") )][ChkBounds( (hitY2) / 24, 19, 170, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 7; 
  hitY2 -= 7; 
  heightCounter += 1; 
  } 
  if ( (-(heightCounter == 12)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 179, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 179, CFSTR("IWBTG.main") )] ) ) == 0 )) ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  } 
  if ( jumpNo > 1 ) 
  { 
  FBColor( 0 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 191, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 191, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 7; 
  hitY2 -= 7; 
  heightCounter += 1; 
  } 
  if ( (-(heightCounter == 8)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 199, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 199, CFSTR("IWBTG.main") )] ) ) == 0 )) ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pdown" ) ) == 0 ) 
  { 
  if ( jumpNo == 1 ) 
  { 
  FBColor( 0 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 212, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 212, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 7; 
  hitY2 += 7; 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 218, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 218, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  if ( (-(jumpNo >= 2)) & (-(hitY1 < tempJump)) ) 
  { 
  FBColor( 0 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 228, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 228, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 7; 
  hitY2 += 7; 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 236, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 236, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  } 
 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), leftRight )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
  if ( ((hitX2 - 12) / 24) >= 0 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( (hitX2 - 12) / 24, 25, 255, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 255, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 -= 12; 
  hitX2 -= 12; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  } 
  PSstrcpy( lastDir, "\pa" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX2 / 24 + 1, 25, 270, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24, 19, 270, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 += 12; 
  hitX2 += 12; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  PSstrcpy( lastDir, "\pd" ); 
  } 
 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
 
  if ( bul1X != 0 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( bul1X / 24 + 1, 25, 302, CFSTR("IWBTG.main") )][ChkBounds( (bul1Y - 12) / 24 + 1, 19, 302, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir1 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir1, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir1, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), bulDir1 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul1X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul1X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
  } 
  else 
  { 
  PSstrcpy( bulDir1, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul1X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul1Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul1X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul1Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul1X = 0; 
  bul1Y = 0; 
  } 
  } 
  if ( bul2X != 0 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( bul2X / 24 + 1, 25, 355, CFSTR("IWBTG.main") )][ChkBounds( (bul2Y - 12) / 24 + 1, 19, 355, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir2 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir2, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir2, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), bulDir2 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul2X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul2X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
  } 
  else 
  { 
  PSstrcpy( bulDir2, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul2X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul2Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul2X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul2Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul2X = 0; 
  bul2Y = 0; 
  } 
  } 
  if ( bul3X != 0 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( bul3X / 24 + 1, 25, 405, CFSTR("IWBTG.main") )][ChkBounds( (bul3Y - 12) / 24 + 1, 19, 405, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir3 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir3, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir3, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), bulDir3 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul3X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul3X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
  } 
  else 
  { 
  PSstrcpy( bulDir3, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul3X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul3Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul3X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul3Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul3X = 0; 
  bul3Y = 0; 
  } 
  } 
  if ( (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks[ChkBounds( hitX1 / 24 + 1, 25, 454, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24 + 1, 19, 454, CFSTR("IWBTG.main") )] ) ) != 0 )) & (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), upDown ) ) == 0 )) ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 12; 
  hitY2 += 12; 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
 
  } 
  PSstrcpy( inkey, "\p" ); 
  loopCycle++; 
  if ( loopCycle == 2 ) 
  { 
  loopCycle = 0; 
  PSstrcpy( inkey, FBInkey() ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), inkey ) ) != 0  ) 
  { 
  PSstrcpy( inkeyFill, "\pyup" ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), inkey )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\p " ) ) == 0 ) 
  { 
  jumpNo += 1; 
  if ( jumpNo <= 2 ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pup" ); 
  if ( jumpNo == 1 ) 
  { 
  tempJump = hitY1; 
  } 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pa" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pd" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pm" ) ) == 0 ) 
  { 
  GOSUB bullet_123; 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  } 
  } 
  } 
  while ( !(  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pover" ),  PSstrcpy( STACK_PUSH(), game ) ) == 0  ) ); 
  FBStopMsg( PSstrcpy( STACK_PUSH(), "\pStop"), 521 ); 
bullet_123:; 
  if ( bul1X == 0 ) 
  { 
  bul1X = hitX1; 
  bul1Y = (hitY1 + hitY2) / 2; 
  RETURN_FROM_GOSUB; 
  } 
  if ( (-(bul1X != 0)) & (-(bul2X == 0)) ) 
  { 
  bul2X = hitX1; 
  bul2Y = (hitY1 + hitY2) / 2; 
  RETURN_FROM_GOSUB; 
  } 
  if ( (-(bul1X != 0)) & ((-(bul2X != 0)) & (-(bul3X == 0))) ) 
  { 
  bul3X = hitX1; 
  bul3Y = (hitY1 + hitY2) / 2; 
  RETURN_FROM_GOSUB; 
  } 
  RETURN_FROM_GOSUB; 
  return 0; 
} 
  

