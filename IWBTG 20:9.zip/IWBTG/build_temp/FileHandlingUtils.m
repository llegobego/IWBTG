#include "FileHandlingUtils.h"
#include "ArrayIndices.h"

///////////////////////////////////////////////////
//       translated globals and fns              //
///////////////////////////////////////////////////

FBBoolean  FH_FileExistsAtPath( CFStringRef path ) {
    FBBoolean  exists = false;
    if( path ) exists = [[NSFileManager defaultManager] fileExistsAtPath:(NSString *)path];
    return exists;
}


FBBoolean  FH_LastFileExists( CFURLRef url ) {
    FBBoolean  exists = false;
    if( url ) exists = FH_FileExistsAtPath((CFStringRef)[(NSURL *)url path] );
    return exists;
}


CFURLRef  FH_AppendComponentToURL( CFURLRef baseURL, CFStringRef componentToAppend ) {
    return(CFURLRef)[(NSURL *)baseURL URLByAppendingPathComponent:(NSString *)componentToAppend];
    return NULL;
}


CFStringRef  FH_AppendComponentToString( CFStringRef basePath, CFStringRef componentToAppend ) {
    return(CFStringRef)[(NSString *)basePath stringByAppendingPathComponent:(NSString *)componentToAppend];
    return NULL;
}


CFURLRef  FH_GetBundleResourceDirectoryURL() {
    return(CFURLRef)[[NSBundle mainBundle] resourceURL];
    return NULL;
}

/*
 CFURLRef  FH_GetSysDirAndPathURL( UInt32 whichDirectory, UInt32 whichDomain, CFStringRef whichAppendComponent ) {
 CFURLRef          url1;
 CFURLRef          url2;
 url1 = SystemDirectoryCopyURL( whichDirectory, whichDomain );
 url2 = FH_AppendComponentToURL( url1, whichAppendComponent );
 CFRelease( url1 );
 return url2;
 }
 */

long  FH_GetFileType( CFURLRef url, OSType * type ) {
    NSDictionary *attributes = [[NSFileManager defaultManager] attributesOfItemAtPath:[(NSURL *)url path] error:nil];
    *type = [[attributes objectForKey:NSFileHFSTypeCode] unsignedLongValue];
    //*creator = [[attributes objectForKey:NSFileHFSCreatorCode] unsignedLongValue];
    return 0;
}


void  FH_SetTypeCreator( CFURLRef fileURL, OSType type, OSType creator ) {
    NSString *filePath = [(NSURL *)fileURL path];
    NSNumber *typeNum = [NSNumber numberWithInt:type];
    NSNumber *creatorNum = [NSNumber numberWithInt:creator];
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:typeNum forKey:NSFileHFSTypeCode];
    [attributes setObject:creatorNum forKey:NSFileHFSCreatorCode];
    [[NSFileManager defaultManager] setAttributes:attributes ofItemAtPath:filePath error:nil];
}


OSStatus FH_SetFilePointerToEndOfFile( CFURLRef url, SInt64 *filePos ) {
    OSStatus err = noErr;
    NSError *fhError = nil;
    
    NSFileHandle *fh =[NSFileHandle fileHandleForReadingFromURL:(NSURL *)url error:&fhError];
    UInt64 length = FH_FileLength( url );

    @try {
        [fh seekToFileOffset: length];
        
    } @catch (NSException *theException) {
        if (theException.name == NSFileHandleOperationException) {
            err = fnOpnErr;
        }
    }
    
    //@finally {
    
    //}
    *filePos = length;
    return err;
}


UInt64  FH_FileLength( CFURLRef url ) {
    NSError *fhError = nil;
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingFromURL:(NSURL *)url error:&fhError];
    if ( !fhError ) {
        UInt64    offSet = [fh offsetInFile];     // save current offset
        UInt64    length = [fh seekToEndOfFile];
        [fh seekToFileOffset:offSet];             // restore offset in file
                                                  //[fh release];
        return length;
    } else {
        return 0;
    }
}
UInt64 FH_CurrentOffsetInFile( CFURLRef url ) {
    UInt64    offSet = 0;
    NSError *fhError = nil;
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingFromURL:(NSURL *)url error:&fhError];
    if ( !fhError ) {
        offSet = [fh offsetInFile];
    }
    return offSet;
}

NSData * FH_ReadData( CFURLRef url, NSUInteger length, SInt64 *offset ) {
    NSError *fhError = nil;
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingFromURL:(NSURL *)url error:&fhError];
    [fh seekToFileOffset:*offset];
    NSData *data = [fh readDataOfLength:length];
    *offset = [fh offsetInFile];
    return data;
}

long  FH_PrintFile( CFURLRef url, CFStringRef string ) {
    [(NSString *)string writeToURL:(NSURL *)url atomically:NO encoding:NSUTF8StringEncoding error:nil];
    return 0;
}


CFStringRef  FH_InputFile( CFURLRef url, CFStringRef string ) {
    string = (CFStringRef)[NSString stringWithContentsOfURL:(NSURL *)url encoding:NSUTF8StringEncoding error:nil];
    return string;
}


OSStatus  FH_ReadChar( CFURLRef url, SInt64 * offset, UInt8 *value ) {
    OSStatus err = 0;
    NSData *data = FH_ReadData( url, sizeof(char), offset );
    if( data != nil ) {
        [data getBytes:value length:[data length]];
    } else {
        err = ioErr;
    }
    return err;
}

void  FH_ReadFile( CFURLRef url, void *p, SInt64 length, SInt64 *offset ) {
    NSData *data = FH_ReadData( url, length, offset ); // allow for file already being read and this is a subsequent read.
    [data getBytes:p length: [data length]];
}


UInt64 FH_TruncateFileAtOffset( NSFileHandle *fh,  UInt64 inOffset ) {
    [fh seekToFileOffset:inOffset];
    [fh truncateFileAtOffset: inOffset];
    //[fh closeFile];
    return inOffset;
}
OSStatus FH_CheckFileLockStatus( int fd, int inStatusType, int *outFileLockStat ) {
    OSStatus err = noErr;
    struct flock fileLockRec = { 0, 0, 0, 0, 0 };
    
    //fileLockRec.l_type = F_WRLCK;
    //fileLockRec.l_type = F_RDLCK;
    fileLockRec.l_type = inStatusType;
    err = fcntl( fd, F_GETLK, &fileLockRec );
    if ( err >= 0 ) {
        *outFileLockStat = (int)fileLockRec.l_type;     // if no lock found to prevent a F_WRLCK( or F_RDLCK ), the lock type is set to F_UNLCK.
    } else {
        err = errno;
    }
    return err;
}
/*
OSStatus FH_CheckFileLockStatus( CFURLRef url, int *fileLockStat ) {
    NSError *fhError = nil;
    OSStatus err = noErr;
    int localFD;
    struct flock fileLockRec = { 0, 0, 0, 0, 0 };
    
    NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingURL: (NSURL *)url error:&fhError];   // make available to flock() call.  Not returned to caller.
    
    if ( fhError ) {
        err = [fhError code];
    } else {
        localFD = [fh fileDescriptor];
        fileLockRec.l_type = F_WRLCK;
        int errNo = fcntl( localFD, F_GETLK, &fileLockRec );
        if ( errNo >= 0 ) {
            *fileLockStat = (int)fileLockRec.l_type;     // if no lock found that would prevent a F_WRLCK, the lock type is set to F_UNLCK.

        } else {
            err = errNo;
            if ( err == ENOTSUP ) {                 // possibly a network file...
                err = flock( localFD, LOCK_UN );    //...if no error, we supposing file is unlocked...
                if ( err == noErr )
                    *fileLockStat = F_UNLCK;
                else
                    err = errno;
            }
        }
        //close( localFD );
    }
    return err;
}
*/
// 'Updateable' means available for reading and writing
// 'Writable'   means available only for writing.
OSStatus FH_IsFileAvailable( CFURLRef url, char *modeRequested, int *fd ) {
    OSStatus err  = noErr;
    int openFileMode, localFD, fileLockStat = 0;
    
    const char *pathName = [[(NSURL *)url path] UTF8String];
    // Does another process have this file open?
    localFD = [[NSFileHandle fileHandleForReadingFromURL:(NSURL *)url error:NULL]fileDescriptor];  // file handle creation does not install a lock on the file
    err = FH_CheckFileLockStatus( localFD, F_WRLCK, &fileLockStat );
    close( localFD );

    switch ( *modeRequested ) {
        case 'N': openFileMode = O_RDWR   | O_SHLOCK   | O_NONBLOCK;
            if ( err == noErr ) {
                switch ( fileLockStat ) {
                    case F_RDLCK:                            // at least one process has a shared lock
                        *modeRequested = 'I';                // need to do an open "I" since other process has a shared lock
                        err = EACCES;                        // tell caller write permission denied
                        openFileMode = O_RDONLY   | O_SHLOCK   | O_NONBLOCK;
                    case F_UNLCK:                            // means file is unlocked and available.
                        localFD = open(pathName, openFileMode);
                        *fd = localFD;
                        break;
                    case F_WRLCK:                            // one process has an exclusive or write lock
                        err = EAGAIN;                        // resource temporarily not available
                        break;
                }
            }
            break;
        case 'I': openFileMode = O_RDONLY | O_SHLOCK   | O_NONBLOCK;
            if ( err == noErr ) {
                switch ( fileLockStat ) {
                    case F_RDLCK:                            // at least one process has a shared lock
                        err = EACCES;                        // tell caller write permission denied
                                                             // 'break' intentionally omitted
                    case F_UNLCK:                            // means file is unlocked and available.
                        localFD = open(pathName, openFileMode);
                        *fd = localFD;
                        break;
                    case F_WRLCK:                            // one process has an exclusive or write lock
                        err = EAGAIN;                        // resource temporarily not available
                        break;
                }
            }

            break;
        case 'O':
        case 'A':
        case 'R': openFileMode = O_RDWR   | O_EXLOCK   | O_NONBLOCK;   // modes 'O','A','R' are all exclusive
            if ( err == noErr ) {
                switch ( fileLockStat ) {
                    case F_RDLCK:                            // at least one process has a shared lock
                    case F_WRLCK:                            // one process has an exclusive or write lock
                        err = EAGAIN;                        // resource temporarily not available
                        break;
                    case F_UNLCK:                            // means file is unlocked and available.
                        localFD = open(pathName, openFileMode);
                        *fd = localFD;
                        break;
                }
            }
            break;
        default:
            err = 999; // invalid modeRequested
            break;
            
    }
    
    return err;
}
//UInt64  WriteData( CFURLRef url, CFDataRef inData, UInt64 inOffset )
UInt64  FH_WriteData( CFURLRef url, CFDataRef inData, UInt64 inOffset ) {
    //NSFileHandle *fh = [NSFileHandle fileHandleForWritingToURL:(NSURL *)url error:nil];
    NSError *fhError = nil;
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingToURL:(NSURL *)url error:&fhError];
    [fh seekToFileOffset:inOffset];
    [fh writeData:(NSData *)inData];
    UInt64 outOffset = [fh offsetInFile];
    //[fh truncateFileAtOffset: outOffset];
    //[fh release];
    return outOffset;
}

//UInt64  WriteFile( CFURLRef url, void *p, UInt64 length, UInt64 offset )
UInt64  FH_WriteFile( CFURLRef url, void *p, UInt64 length, UInt64 offset ) {
    //UInt64  WriteFile( CFURLRef url, CFStringRef mutInString, UInt64 length, UInt64 offset ) {
    //UInt64            outOffset;
    //UInt64 outOffset = WriteData( url,(CFDataRef)[NSData dataWithBytes:p length:length], offset );
    //outOffset = WriteData( url,(CFDataRef)[(NSString *)mutInString dataUsingEncoding:NSUTF8StringEncoding], offset );
    //NSData* data     = [[(id)mutInString dataUsingEncoding:NSUTF8StringEncoding]retain];
    //UInt64 outOffset = WriteData( url,(CFDataRef)data, offset );
    //[data release];
    return FH_WriteData( url,(CFDataRef)[NSData dataWithBytes:p length:length], offset );
}


UInt64  FH_WriteChar( CFURLRef url, char theChar, SInt64 offset ) {
    //UInt64            outOffset;
    //outOffset = WriteData( url,(CFDataRef)[NSData dataWithBytes:&theChar length:sizeof(theChar)], offset );
    return FH_WriteData( url, (CFDataRef)[NSData dataWithBytes:&theChar length:sizeof(theChar)], offset );;
}

CFStringRef FH_URLGetPath( CFURLRef url ) {
    return (CFStringRef)[(NSURL *)url path];
}

BOOL  FH_BuildEmptyFile( CFURLRef url ) {
    NSFileManager *fm = [NSFileManager defaultManager];
    return [fm createFileAtPath: (NSString *)FH_URLGetPath( url ) contents:nil attributes:nil];
}



long  FH_FSpTrashObject( CFStringRef sourceObj ) {
    OSErr             err;
    err = noErr;
    if ( sourceObj ) {
        //NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
        NSString *src = [(NSString *)sourceObj stringByDeletingLastPathComponent];
        NSString *file = [(NSString *)sourceObj lastPathComponent];
        [[NSWorkspace sharedWorkspace] performFileOperation:NSWorkspaceRecycleOperation source:src destination:@"" files:[NSArray arrayWithObject:file] tag:nil];
        NSSound *systemSound = [[NSSound alloc] initWithContentsOfFile:@"/System/Library/Components/CoreAudio.component/Contents/SharedSupport/SystemSounds/dock/drag to trash.aif" byReference:YES];
        if(systemSound) {
            [systemSound play];
            [systemSound release];
        }
        //[pool drain];
    } else {
        err = 999;
    }
    return err;
}
/*
 CFURLRef OSPanelOpen( UInt32 options, CFStringRef message, CFTypeRef allowedFileTypes, CFStringRef prompt, CFURLRef dirURL ) {
 return NULL;
 }
 */
