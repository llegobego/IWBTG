#ifndef H0_TRANSLATEDRUNTIME
#define H0_TRANSLATEDRUNTIME

#import <AppKit/AppKit.h>
#include "FBtoC.h"
#include "Runtime.h"

///////////////////////////////////////////////////
//  prototypes + translated #defines and records //
///////////////////////////////////////////////////
 
#if MAC_OS_X_VERSION_10_4 >= MAC_OS_X_VERSION_MAX_ALLOWED
typedef UInt32 URefCon;
typedef SInt32 SRefCon;
#endif
long  FBInstallAEHandler( long aeClass, long aeType, void* aeProc, SRefCon x, FBBoolean y ) 
;
long  Date2Secs( void* recPtr ) 
;


typedef struct  __attribute__ ((__packed__)) 	CFSTRRec
{
  CFStringRef       cfStr;
  Str255            s;
} CFSTRRec;
CFStringRef  CFStr( Str255 s_p ) 
;
long  FBPStr2CStr( void* strPtr ) 
;
long  FBCStr2PStr( void* strPtr ) 
;
long  FBDoTab( long tabNum ) 
;
extern SInt8             gFBUpperChar[256]; 
extern SInt8             gFBLowerChar[256]; 
long  InitFBGlobals() 
;


typedef Handle 		THPrint;
long  FBGetScreenRect( Rect * rectPtr ) 
;
long  FBGetControlRect( ControlRef c, Rect * rectPtr ) 
;
WindowRef  GetWRefFromPort() 
;
long  CStubInvalRect( Rect * rectPtr ) 
;
long  CStubValidRect( Rect * rectPtr ) 
;
long  CStubInvalRgn( RgnHandle h ) 
;
long  CStubValidRgn( RgnHandle h ) 
;
extern ResType           gFBAEType; 
extern long              gFBAEEvent; 
extern AEDesc *          gFBAEReply; 
extern OSErr             gFBAEError; 
long  FBAEUserAppleEvent( AEDesc * theAEvent, AEDesc * replyEvent, long handlerRefCon ) 
;
long  FBInstallUserAppleEvent( ResType aeClass, ResType aeType ) 
;
long  FBAEerror( long where, OSStatus err ) 
;
long  FBSendAppleEvent( ResType aeClass, ResType aeType, void* msgPtr, long msgLen, Str255 toName_p ) 
;
long  FBRemoveAppleEvent( ResType aeClass, ResType aeType ) 
;
extern CFBundleRef       gSysBundle; 
CFBundleRef  CreateBundleForFramework( Str255 framework_p ) 
;
void*  GetMachFunctionFromBundle( void* bndl, Str255 name_p ) 
;
UInt32  DynamicNextElement( UInt8 array ) 
;
long  DynamicRemoveItems( SInt32 dynArrayNum, SInt32 first, SInt32 howMany, void* savePtr ) 
;
long  DynamicInsertItems( SInt32 dynArrayNum, SInt32 where, SInt32 howMany, void* fillPtr ) 
;
extern SndListResource ** gFBSndHndl; 
extern SndCommand        gFBSndCmd; 
extern SndChannelPtr     gFBSndChanPtr; 
long  FBSndProc( SndChannelPtr unusedChandPtr, SndCommand * unusedSndCmd ) 
;
long  FBSoundEnd() 
;
long  FBPlaySoundHandle() 
;
long  FBSoundType1( long unusedSoundType, void* soundPtr ) 
;
long  FBSound( long SoundType, long soundRef ) 
;
long  FBSoundStrExpr( void* soundPtr ) 
;
long  SoundFreqDur( long freq, long dur, long vol, long async ) 
;
long  SetButtonFocus( long btnID ) 
;
long  DrawOneControlAndValidateRect( ControlRef c ) 
;
long  EmbedButton( long childID, long parentsID ) 
;
long  SetButtonData( long btnID, short part, ResType tagName, long size, void* dPtr ) 
;
long  SetButtonTextString( long btnID, Str255 s_p ) 
;
StringPtr ButtonTextString( long btnID ) 
;
long  GetButtonData( long btnID, short part, ResType tagName, long maxSize, void* dPtr, long * actSize ) 
;
long  ButtonDataSize( long btnID, short part, ResType tagName ) 
;
long  SetButtonTextSelection( long btnID, short selStart, short selEnd ) 
;
long  GetButtonTextSelection( long btnID, short * selStart, short * selEnd ) 
;
long  SetButtonFontStyle( long btnID, ControlFontStyleRec * cfs ) 
;
long  BtnRect( Rect * rPtr, long btnNum ) 
;
ControlRef  FindFBBtnControl( WindowRef w, long butNum ) 
;
ControlRef  FBFindEF( long efNum, long subclassUnused, WindowRef w ) 
;


typedef double 		FB_double;
extern Str255            gFBControlText; 
extern WindowPositionMethod gNewWndPositionMethod; 
long  FBXInitBSDSystemFramework() 
;
long  e_xit( SInt32 status ) 
;
extern UInt16            gFBSerialPortCount; 
extern Str63             gFBSerialName[13]; 
extern Str63             gFBSerialInName[13]; 
extern Str63             gFBSerialOutName[13]; 
extern FBBoolean         gOSXSerialInited; 
long  FBXSerialGetSerialIterator( io_iterator_t * matchingServices ) 
;
long  FBXSerialGetCountAndNames( io_iterator_t serialPortIterator ) 
;
long  FBXSerialSetBaud( termios * options, long speed ) 
;
long  FBXOpenSerialPort( Str255 path_p, long speed, long parity, long stopBits, long charSize, termios * origOptions ) 
;
long  FBXHandShake( long fileDescriptor, long controlMode ) 
;
long  FBInitSerialPorts() 
;
long  FBSerialOpen( long fileRef, long baudRate, long parity, long stopBits, long charSize, long buffSize ) 
;
long  FBHandShake( long fileRef, long flags ) 
;
long  TermGetStatus( long fileRef ) 
;
long  FBGetFolderName( long DirID, short WDRefNum, void* StrPtr ) 
;
void  BlockFill( void* address, unsigned long bytes, long byteVal ) 
;
void  LongBlockFill( void* address, unsigned long bytes, long byteVal ) 
;
long  Handle2Btn( ControlRef c ) 
;
void  FLASH() 
;
void  ORSICN( long x, long y, long rID ) 
;
void  DisposeH( Handle * vPtr ) 
;
void  FBScroll( Rect * r, long dx, long dy ) 
;
void  SHOWPOP( Rect * rPtr ) 
;
void  CopyRect( Rect * rect1, Rect * rect2 ) 
;
long  RemoveStr( Handle strH, long oneBasedItem ) 
;
void  SHADOWBOX( Rect * rectPtr ) 
;
void  CheckOneItem( long menuId, long itemId ) 
;
void  apndstr( Str255 t_p, Handle h ) 
;
void  APNDLNG( long param, Handle h ) 
;
void  CBOX( Rect * rPtr, void* StrPtr ) 
;
void  LBOX( Rect * rPtr, void* StrPtr ) 
;
void  RBOX( Rect * rPtr, void* StrPtr ) 
;
void  TRUNCATE( void* StrPtr ) 
;
void  TITLERECT( Str255 s_p, short xOff, Rect * RectPtr ) 
;
long  FONTHEIGHT() 
;
long  ROUND( double f ) 
;
long  roundUp( double f ) 
;
long  roundDown( double f ) 
;
long  Wptr2WNum( WindowRef w ) 
;
long  STROFFSET( long element, long rID ) 
;
void  ChangedResourceX( Handle rH ) 
;
Handle  ReplaceResource( Handle rH, OSType rTp, short rID, Str255 rName_p, short rRef ) 
;
void*  GetPict( Rect * r ) 
;
void  LCOPY() 
;
void  ClearHandle( Handle h ) 
;
void  LCASE( void* sPtr ) 
;
void  SmallDebugWindow( Str255 msg_p ) 
;
void  DEBUGNUMBER( double theNum ) 
;
void  DEBUGSTRING( Str255 msg_p ) 
;
void  DEBUGRECT( Rect * r ) 
;
void  SetWindowBackground( RGBColor * inBackRGB, FBBoolean applyNow ) 
;
void  InvalRect( Rect * r ) 
;
 
#include "OSPanel.h"
void  NewWindowPositionMethod( WindowPositionMethod pMethod ) 
;
void  WindowReposition( long wNum, long parentWNum, WindowPositionMethod pMethod ) 
;
void  WindowCategory( long wNum, long wCategory ) 
;


#endif /* H0_TRANSLATEDRUNTIME */
