#ifndef H1_BASKETBALL_BAS_BASKETBALL
#define H1_BASKETBALL_BAS_BASKETBALL

#import <AppKit/AppKit.h>
#include "FBtoC.h"
#include "Runtime.h"
#include  "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//  prototypes + translated #defines and records //
///////////////////////////////////////////////////
Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
;
extern Handle            pictH; 
extern Rect              r; 
extern Str255            lastDir; 
extern short             hitX1; 
extern short             hitY1; 
extern short             hitX2; 
extern short             hitY2; 
extern short             distanceCheck; 
extern short             randInt; 
extern Str255            inkey; 
extern short             heightCounter; 
extern Str255            inkeyFill; 
extern Str255            upDown; 
extern Str255            game; 
extern short             score; 
extern short             loopCycle; 
extern Str255            scoreCheck; 
extern Str255            leftRight; 
extern short             jumpNo; 
extern short             tempJump; 
extern short             index1; 
extern short             index2; 
extern Str255            blocks[26][20]; 
extern Str255            object; 
extern CFURLRef          fPath; 
extern short             bul1X; 
extern short             bul1Y; 
extern short             bul2X; 
extern short             bul2Y; 
extern short             bul3X; 
extern short             bul3Y; 
extern Str255            bulDir1; 
extern Str255            bulDir2; 
extern Str255            bulDir3; 
extern Str255            bul1Flag; 
extern Str255            hitBrickX; 
extern Str255            hitBrickY; 
extern Str255            prevCheck; 
extern short             replacementBlockX1; 
extern short             replacementBlockX2; 
extern short             replacementBlockY1; 
extern short             replacementBlockY2; 


#endif /* H1_BASKETBALL_BAS_BASKETBALL */
