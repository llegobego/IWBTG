#include "_1_IWBTG.main,IWBTG.h"
#include "ArrayIndices.h"

#include "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//       translated globals and fns              //
///////////////////////////////////////////////////
 


Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
{
  GraphicsImportComponent gi; 
  ComponentResult   result; 
  PicHandle         pictH; 
  pictH = NULL; 
  CFURLRef          url; 
  FSRef             fsRef; 
  FSSpec            fsSpec; 
  OSErr             err; 
  FBBoolean         success; 
  url = CFBundleCopyResourceURL( CFBundleGetMainBundle(), imageName, NULL, NULL ); 
  if ( url ) 
  { 
  success = CFURLGetFSRef( url, (void*)&fsRef ); 
  CFRelease( url ); 
  if ( success ) 
  { 
  err = FSGetCatalogInfo( (void*)&fsRef, 0, NULL, NULL, &fsSpec, NULL ); 
  if ( err == noErr ) 
  { 
  err = GetGraphicsImporterForFile( (void*)&fsSpec, (void*)&gi ); 
  if ( err == noErr ) 
  { 
  result = GraphicsImportGetAsPicture( gi, (void*)&pictH ); 
  result = GraphicsImportGetBoundsRect( gi, imageRect ); 
  err = CloseComponent( gi ); 
  } 
  } 
  } 
  } 
  return (Handle)pictH; 
}  
  
Handle            pictH; 
Rect              r; 
Str255            lastDir; 
short             hitX1; 
short             hitY1; 
short             hitX2; 
short             hitY2; 
short             distanceCheck; 
short             randInt; 
Str255            inkey; 
short             heightCounter; 
Str255            inkeyFill; 
Str255            upDown; 
Str255            game; 
short             score; 
short             loopCycle; 
Str255            scoreCheck; 
Str255            leftRight; 
short             jumpNo; 
short             tempJump; 
short             index1; 
short             index2; 
Str255            blocks1[26][20]; 
Str255            blocks2[26][20]; 
Str255            object; 
CFURLRef          fPath; 
CFURLRef          fPath2; 
CFURLRef          fPath3; 
FBBoolean         active1; 
FBBoolean         active2; 
short             activeCounter; 
FBBoolean         firstTime; 
short             bul1X; 
short             bul1Y; 
short             bul2X; 
short             bul2Y; 
short             bul3X; 
short             bul3Y; 
Str255            bulDir1; 
Str255            bulDir2; 
Str255            bulDir3; 
Str255            bul1Flag; 
Str255            hitBrickX; 
Str255            hitBrickY; 
Str255            prevCheck; 
short             replacementBlockX1; 
short             replacementBlockX2; 
short             replacementBlockY1; 
short             replacementBlockY2; 
short             level; 
Str255            spikeMoving; 
short             spikeMoving1X1; 
short             spikeMoving1X2; 
short             spikeMoving1Y1; 
short             spikeMoving1Y2; 
short             spikeMoving2X1; 
short             spikeMoving2X2; 
short             spikeMoving2Y1; 
short             spikeMoving2Y2; 
short             spikeMoving3X1; 
short             spikeMoving3X2; 
short             spikeMoving3Y1; 
short             spikeMoving3Y2; 
Str255            triggered; 
Str255            spikeGoBack1; 
Str255            spikeGoBack2; 
Str255            spikeGoBack3; 
short             moveBackDelay1; 
short             moveBackDelay2; 
short             moveBackDelay3; 
Str255            death; 
short             spawnLocX1; 
short             spawnLocX2; 
short             spawnLocY1; 
short             spawnLocY2; 
short             currenttriggerY; 

///////////////////////////////////////////////////
//            translated main code               //
///////////////////////////////////////////////////
int main( int argc, const char * argv[] ) 
{ 
  InitFBGlobals(); 
  FBWindow( 1, CFSTR( "IWBTG" ), (struct CGRect){ { (double)0, (double)0 }, { ((double)600)- ((double)0), ((double)456)- ((double)0) } }, 0, &(int){-1} ); 
  level = 1; 
  spawnLocX1 = 25; 
  spawnLocX2 = 48; 
  spawnLocY1 = 49; 
  spawnLocY2 = 72; 
  fPath3 = (void*)OSpanelOpen( 0, CFSTR( "Select save file" ), CFSTR( "txt" ), CFSTR( "Open" ), NULL ); 
  FBOpenInput( 3, (void*)2, &fPath3, 256, false ); 
  spawnLocX1 = FBReadSwapShort( 3 ); 
  spawnLocX2 = FBReadSwapShort( 3 ); 
  spawnLocY1 = FBReadSwapShort( 3 ); 
  spawnLocY2 = FBReadSwapShort( 3 ); 
  FBClose( 3 ); 
  hitX1 = spawnLocX1; 
  hitX2 = spawnLocX2; 
  hitY1 = spawnLocY1; 
  hitY2 = spawnLocY2; 
  PSstrcpy( triggered, "\pna" ); 
  fPath = (void*)OSpanelOpen( 0, CFSTR( "Select room 1" ), CFSTR( "txt" ), CFSTR( "Open" ), NULL ); 
  fPath2 = (void*)OSpanelOpen( 0, CFSTR( "Select room 2" ), CFSTR( "txt" ), CFSTR( "Open" ), NULL ); 
  FBOpenInput( 1, (void*)2, &fPath, 256, false ); 
 
  for ( index2  = 1; index2 <= 19; index2++ )  { 
 
  for ( index1  = 1; index1 <= 25; index1++ )  { 
 
  gSelectL[1] = level; 
  FBReadString( 1, (char*)&object, 5 );  
 
  PSstrcpy( blocks1[ChkBounds( index1, 25, 196, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 196, CFSTR("IWBTG.main") )], object ); 
  } 
  } 
  FBClose( 1 ); 
  FBOpenInput( 2, (void*)2, &fPath2, 256, false ); 
 
  for ( index2  = 1; index2 <= 19; index2++ )  { 
 
  for ( index1  = 1; index1 <= 25; index1++ )  { 
 
  gSelectL[1] = level; 
  FBReadString( 2, (char*)&object, 5 );  
 
  PSstrcpy( blocks2[ChkBounds( index1, 25, 214, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 214, CFSTR("IWBTG.main") )], object ); 
  } 
  } 
  FBClose( 2 ); 
  GOSUB draw; 
 
  do 
  { 
  if ( (-(hitY1 > 0)) & (-(hitY2 < 450)) ) 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), upDown )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pup" ) ) == 0 ) 
  { 
  if ( jumpNo == 1 ) 
  { 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 237, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 237, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 6; 
  hitY2 -= 6; 
  heightCounter += 1; 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 246, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 246, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 6; 
  hitY2 -= 6; 
  heightCounter += 1; 
  } 
  } 
 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if ( (-(heightCounter == 12)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 259, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 259, CFSTR("IWBTG.main") )] ) ) == 0 )) ) 
  { 
  heightCounter = 0; 
  hitY1 += 6; 
  hitY2 += 6; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if ( (-(heightCounter == 12)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( hitX1 / 24 + 1, 25, 267, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 267, CFSTR("IWBTG.main") )] ) ) == 0 )) ) 
  { 
  heightCounter = 0; 
  hitY1 += 6; 
  hitY2 += 6; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  } 
 
  } 
  if ( jumpNo > 1 ) 
  { 
  FBColor( 0 ); 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 282, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 282, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 6; 
  hitY2 -= 6; 
  heightCounter += 1; 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( hitX1 / 24 + 1, 25, 290, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 290, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 6; 
  hitY2 -= 6; 
  heightCounter += 1; 
  } 
  } 
 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if ( (-(heightCounter == 8)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 302, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 302, CFSTR("IWBTG.main") )] ) ) == 0 )) ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  hitY1 += 6; 
  hitY2 += 6; 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if ( (-(heightCounter == 8)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( hitX1 / 24 + 1, 25, 310, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 310, CFSTR("IWBTG.main") )] ) ) == 0 )) ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  hitY1 += 6; 
  hitY2 += 6; 
  } 
  } 
 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pdown" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 328, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 328, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 6; 
  hitY2 += 6; 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( hitX1 / 24 + 1, 25, 334, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 334, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 6; 
  hitY2 += 6; 
  } 
  } 
 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 343, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 343, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( hitX1 / 24 + 1, 25, 349, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24 + 2, 19, 349, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
 
  } 
 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), leftRight )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
  if ( ((hitX2 - 12) / 24) >= 0 ) 
  { 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( (hitX2 - 12) / 24, 25, 390, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 390, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 -= 12; 
  hitX2 -= 12; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( (hitX2 - 12) / 24, 25, 398, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24, 19, 398, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 -= 12; 
  hitX2 -= 12; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  } 
 
  } 
  PSstrcpy( lastDir, "\pa" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
 
  gSelectL[2] = level; 
  if ( gSelectL[2] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( (hitX2 / 24 + 1), 25, 416, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24, 19, 416, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 += 12; 
  hitX2 += 12; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( (hitX2 / 24 + 1), 25, 425, CFSTR("IWBTG.main") )][ChkBounds( hitY1 / 24, 19, 425, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 += 12; 
  hitX2 += 12; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  } 
 
  PSstrcpy( lastDir, "\pd" ); 
  } 
 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep1" ),  PSstrcpy( STACK_PUSH(), spikeGoBack1 ) ) == 0  ) 
  { 
  if ( moveBackDelay1 == 50 ) 
  { 
  if ( spikeMoving1X1 > 25 ) 
  { 
  FBColor( 0 ); 
  FBBox( spikeMoving1X1, spikeMoving1Y1, spikeMoving1X2, spikeMoving1Y2, 1 ); 
  spikeMoving1X1 -= 2; 
  spikeMoving1X2 -= 2; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving1Y1, spikeMoving1X1, spikeMoving1Y2, spikeMoving1X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else 
  { 
  PSstrcpy( spikeGoBack1, "\pna" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving1X1, spikeMoving1Y1, spikeMoving1X2, spikeMoving1Y2, 1 ); 
  } 
  } 
  else 
  { 
  moveBackDelay1 += 1; 
  } 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep2" ),  PSstrcpy( STACK_PUSH(), spikeGoBack2 ) ) == 0  ) 
  { 
  if ( moveBackDelay2 == 50 ) 
  { 
  if ( spikeMoving2X1 < 552 ) 
  { 
  FBColor( 0 ); 
  FBBox( spikeMoving2X1, spikeMoving2Y1, spikeMoving2X2, spikeMoving2Y2, 1 ); 
  spikeMoving2X1 += 2; 
  spikeMoving2X2 += 2; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving2Y1, spikeMoving2X1, spikeMoving2Y2, spikeMoving2X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else 
  { 
  PSstrcpy( spikeGoBack2, "\pna" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving2X1, spikeMoving2Y1, spikeMoving2X2, spikeMoving2Y2, 1 ); 
  } 
  } 
  else 
  { 
  moveBackDelay2 += 1; 
  } 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike1" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0  ) 
  { 
  if ( spikeMoving1X1 < 504 ) 
  { 
  FBColor( 0 ); 
  FBBox( spikeMoving1X1, spikeMoving1Y1, spikeMoving1X2, spikeMoving1Y2, 1 ); 
  spikeMoving1X1 += 30; 
  spikeMoving1X2 += 30; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving1Y1, spikeMoving1X1, spikeMoving1Y2, spikeMoving1X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  if ( spikeMoving1X1 == 505 ) 
  { 
  PSstrcpy( spikeGoBack1, "\pyep1" ); 
  PSstrcpy( triggered, "\pna" ); 
  moveBackDelay1 = 0; 
  } 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike2" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0  ) 
  { 
  if ( spikeMoving2X1 > 73 ) 
  { 
  FBColor( 0 ); 
  FBBox( spikeMoving2X1, spikeMoving2Y1, spikeMoving2X2, spikeMoving2Y2, 1 ); 
  spikeMoving2X1 -= 30; 
  spikeMoving2X2 -= 30; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving2Y1, spikeMoving2X1, spikeMoving2Y2, spikeMoving2X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  if ( spikeMoving2X1 == 72 ) 
  { 
  PSstrcpy( spikeGoBack2, "\pyep2" ); 
  PSstrcpy( triggered, "\pna" ); 
  moveBackDelay2 = 0; 
  } 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike3" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0  ) 
  { 
  if ( spikeMoving2X1 > 73 ) 
  { 
  FBColor( 0 ); 
  FBBox( spikeMoving3X1, spikeMoving3Y1, spikeMoving3X2, spikeMoving3Y2, 1 ); 
  spikeMoving3X1 -= 30; 
  spikeMoving3X2 -= 30; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving3Y1, spikeMoving3X1, spikeMoving3Y2, spikeMoving3X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  if ( spikeMoving3X1 == 72 ) 
  { 
  PSstrcpy( triggered, "\pna" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving3X1, spikeMoving3Y1, spikeMoving3X2, spikeMoving3Y2, 1 ); 
  } 
  } 
  if ( (-(level == 1)) & ((-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pna" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0 )) & (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep1" ),  PSstrcpy( STACK_PUSH(), spikeGoBack1 ) ) != 0 ))) ) 
  { 
  currenttriggerY = hitY2 / 24; 
  if ( currenttriggerY == 7 ) 
  { 
  if ( (-(hitX2 / 24 != 23)) & (-(hitX2 / 24 != 24)) ) 
  { 
  spikeMoving1X1 = 25; 
  spikeMoving1X2 = 48; 
  spikeMoving1Y1 = 97; 
  spikeMoving1Y2 = 168; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving1Y1, spikeMoving1X1, spikeMoving1Y2, spikeMoving1X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  PSstrcpy( spikeMoving, "\pyep" ); 
  PSstrcpy( triggered, "\plvl1spike1" ); 
  } 
  } 
  } 
  if ( (-(level == 1)) & ((-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pna" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0 )) & (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep2" ),  PSstrcpy( STACK_PUSH(), spikeGoBack2 ) ) != 0 ))) ) 
  { 
  currenttriggerY = hitY2 / 24; 
  if ( currenttriggerY == 11 ) 
  { 
  if ( (-(hitX2 / 24 != 2)) & (-(hitX2 / 24 != 3)) ) 
  { 
  spikeMoving2X1 = 552; 
  spikeMoving2X2 = 576; 
  spikeMoving2Y1 = 193; 
  spikeMoving2Y2 = 264; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving2Y1, spikeMoving2X1, spikeMoving2Y2, spikeMoving2X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  PSstrcpy( spikeMoving, "\pyep" ); 
  PSstrcpy( triggered, "\plvl1spike2" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving2X1, spikeMoving2Y1, spikeMoving2X2, spikeMoving2Y2, 1 ); 
  } 
  } 
  } 
  if ( (-(level == 1)) & (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pna" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0 )) ) 
  { 
  currenttriggerY = hitY2 / 24; 
  if ( currenttriggerY == 15 ) 
  { 
  if ( (-(hitX2 / 24 == 20)) | ((-(hitX2 / 24 == 21)) | (-(hitX2 / 24 == 22))) ) 
  { 
  spikeMoving3X1 = 552; 
  spikeMoving3X2 = 576; 
  spikeMoving3Y1 = 289; 
  spikeMoving3Y2 = 360; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Many spike LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){spikeMoving3Y1, spikeMoving3X1, spikeMoving3Y2, spikeMoving3X2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  PSstrcpy( spikeMoving, "\pyep" ); 
  PSstrcpy( triggered, "\plvl1spike3" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving3X1, spikeMoving3Y1, spikeMoving3X2, spikeMoving3Y2, 1 ); 
  } 
  } 
  } 
  if ( level == 1 ) 
  { 
  if ( (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike1" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0 )) | ((-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike1" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0 )) | ((-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep1" ),  PSstrcpy( STACK_PUSH(), spikeGoBack1 ) ) == 0 )) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep2" ),  PSstrcpy( STACK_PUSH(), spikeGoBack2 ) ) == 0 )))) ) 
  { 
  if ( (-(hitX1 <= spikeMoving1X2)) & ((-(hitX1 >= spikeMoving1X1)) & ((-(hitY1 <= spikeMoving1Y2)) & (-(hitY2 >= spikeMoving1Y1)))) ) 
  { 
  PSstrcpy( death, "\pyep" ); 
  } 
  } 
  } 
  if ( level == 1 ) 
  { 
  if ( (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike2" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0 )) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep2" ),  PSstrcpy( STACK_PUSH(), spikeGoBack2 ) ) == 0 )) ) 
  { 
  if ( (-(hitX1 <= spikeMoving2X2)) & ((-(hitX1 >= spikeMoving2X1)) & ((-(hitY1 <= spikeMoving2Y2)) & (-(hitY2 >= spikeMoving2Y1)))) ) 
  { 
  PSstrcpy( death, "\pyep" ); 
  } 
  } 
  } 
  if ( level == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike3" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0  ) 
  { 
  if ( (-(hitX1 <= spikeMoving3X2)) & ((-(hitX1 >= spikeMoving3X1)) & ((-(hitY1 <= spikeMoving3Y2)) & (-(hitY2 >= spikeMoving3Y1)))) ) 
  { 
  PSstrcpy( death, "\pyep" ); 
  } 
  } 
  } 
  if ( level == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\plvl1spike3" ),  PSstrcpy( STACK_PUSH(), triggered ) ) == 0  ) 
  { 
  if ( (-(hitX1 <= spikeMoving3X2 + 30)) & ((-(hitX1 >= spikeMoving3X1 - 30)) & ((-(hitY1 <= spikeMoving3Y2)) & (-(hitY2 >= spikeMoving3Y1)))) ) 
  { 
  PSstrcpy( death, "\pyep" ); 
  } 
  } 
  } 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pyep" ),  PSstrcpy( STACK_PUSH(), death ) ) == 0  ) 
  { 
  GOSUB suck; 
  PSstrcpy( death, "\pna" ); 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 = spawnLocX1; 
  hitX2 = spawnLocX2; 
  hitY1 = spawnLocY1; 
  hitY2 = spawnLocY2; 
  PSstrcpy( spikeMoving, "\pna" ); 
  PSstrcpy( triggered, "\pna" ); 
  PSstrcpy( spikeGoBack1, "\pna" ); 
  PSstrcpy( spikeGoBack2, "\pna" ); 
  spikeMoving1X1 = 0; 
  spikeMoving1X2 = 0; 
  spikeMoving1Y1 = 0; 
  spikeMoving1Y2 = 0; 
  spikeMoving2X1 = 0; 
  spikeMoving2X2 = 0; 
  spikeMoving2Y1 = 0; 
  spikeMoving2Y2 = 0; 
  spikeMoving3X1 = 0; 
  spikeMoving3X2 = 0; 
  spikeMoving3Y1 = 0; 
  spikeMoving3Y2 = 0; 
  } 
  if ( bul1X != 0 ) 
  { 
 
  gSelectL[1] = level; 
  if ( gSelectL[1] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( bul1X / 24 + 1, 25, 732, CFSTR("IWBTG.main") )][ChkBounds( (bul1Y - 12) / 24 + 1, 19, 732, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir1 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir1, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir1, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), bulDir1 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul1X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul1X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\psave-" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( bul1X / 24 + 1, 25, 761, CFSTR("IWBTG.main") )][ChkBounds( (bul1Y - 12) / 24 + 1, 19, 761, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  if ( active1 == false ) 
  { 
  GOSUB green; 
  } 
  if ( active2 == false ) 
  { 
  GOSUB green; 
  } 
  } 
  } 
  else 
  { 
  PSstrcpy( bulDir1, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul1X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul1Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul1X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul1Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul1X = 0; 
  bul1Y = 0; 
  } 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( bul1X / 24 + 1, 25, 792, CFSTR("IWBTG.main") )][ChkBounds( (bul1Y - 12) / 24 + 1, 19, 792, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir1 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir1, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir1, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), bulDir1 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul1X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul1X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\psave-" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( bul1X / 24 + 1, 25, 821, CFSTR("IWBTG.main") )][ChkBounds( (bul1Y - 12) / 24 + 1, 19, 821, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  if ( active1 == false ) 
  { 
  GOSUB green; 
  } 
  if ( active2 == false ) 
  { 
  GOSUB green; 
  } 
  } 
  } 
  else 
  { 
  PSstrcpy( bulDir1, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul1X, bul1Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul1X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul1Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul1X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul1Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul1X = 0; 
  bul1Y = 0; 
  } 
  } 
 
  } 
  if ( bul2X != 0 ) 
  { 
 
  gSelectL[1] = level; 
  if ( gSelectL[1] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( bul2X / 24 + 1, 25, 858, CFSTR("IWBTG.main") )][ChkBounds( (bul2Y - 12) / 24 + 1, 19, 858, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir2 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir2, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir2, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), bulDir2 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul2X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul2X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\psave-" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( bul2X / 24 + 1, 25, 884, CFSTR("IWBTG.main") )][ChkBounds( (bul2Y - 12) / 24 + 1, 19, 884, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  if ( active1 == false ) 
  { 
  GOSUB green; 
  } 
  if ( active2 == false ) 
  { 
  GOSUB green; 
  } 
  } 
  } 
  else 
  { 
  PSstrcpy( bulDir2, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul2X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul2Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul2X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul2Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul2X = 0; 
  bul2Y = 0; 
  } 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( bul2X / 24 + 1, 25, 914, CFSTR("IWBTG.main") )][ChkBounds( (bul2Y - 12) / 24 + 1, 19, 914, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir2 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir2, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir2, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), bulDir2 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul2X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul2X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\psave-" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( bul2X / 24 + 1, 25, 940, CFSTR("IWBTG.main") )][ChkBounds( (bul2Y - 12) / 24 + 1, 19, 940, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  if ( active1 == false ) 
  { 
  GOSUB green; 
  } 
  if ( active2 == false ) 
  { 
  GOSUB green; 
  } 
  } 
  } 
  else 
  { 
  PSstrcpy( bulDir2, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul2X, bul2Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul2X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul2Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul2X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul2Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul2X = 0; 
  bul2Y = 0; 
  } 
  } 
 
  } 
  if ( bul3X != 0 ) 
  { 
 
  gSelectL[1] = level; 
  if ( gSelectL[1] == 1 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( bul3X / 24 + 1, 25, 976, CFSTR("IWBTG.main") )][ChkBounds( (bul3Y - 12) / 24 + 1, 19, 976, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir3 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir3, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir3, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), bulDir3 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul3X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul3X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\psave-" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( bul3X / 24 + 1, 25, 1003, CFSTR("IWBTG.main") )][ChkBounds( (bul3Y - 12) / 24 + 1, 19, 1003, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  if ( active1 == false ) 
  { 
  GOSUB green; 
  } 
  if ( active2 == false ) 
  { 
  GOSUB green; 
  } 
  } 
  } 
  else 
  { 
  PSstrcpy( bulDir3, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul3X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul3Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul3X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul3Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul3X = 0; 
  bul3Y = 0; 
  } 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( bul3X / 24 + 1, 25, 1031, CFSTR("IWBTG.main") )][ChkBounds( (bul3Y - 12) / 24 + 1, 19, 1031, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), bulDir3 ) ) == 0  ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir3, "\pleft" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( bulDir3, "\pright" ); 
  } 
 
  } 
  FBColor( 0 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), bulDir3 )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pleft" ) ) == 0 ) 
  { 
  bul3X -= 6; 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pright" ) ) == 0 ) 
  { 
  bul3X += 6; 
  } 
 
  FBColor( 3 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\psave-" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( bul3X / 24 + 1, 25, 1058, CFSTR("IWBTG.main") )][ChkBounds( (bul3Y - 12) / 24 + 1, 19, 1058, CFSTR("IWBTG.main") )] ) ) == 0  ) 
  { 
  if ( active1 == false ) 
  { 
  GOSUB green; 
  } 
  if ( active2 == false ) 
  { 
  GOSUB green; 
  } 
  } 
  } 
  else 
  { 
  PSstrcpy( bulDir3, "\p" ); 
  FBColor( 0 ); 
  FBCircle( bul3X, bul3Y, 5, 0, 0 , 0xFFFF0000 ); 
  replacementBlockX1 = ((bul3X / 24 + 1) * 24) - 24; 
  replacementBlockY1 = (((bul3Y - 12) / 24) * 24); 
  replacementBlockX2 = ((bul3X / 24 + 1) * 24); 
  replacementBlockY2 = (((bul3Y - 12) / 24) * 24) + 24; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  FBPicture( &(Rect){replacementBlockY1, replacementBlockX1, replacementBlockY2, replacementBlockX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  bul3X = 0; 
  bul3Y = 0; 
  } 
  } 
 
  } 
 
  gSelectL[1] = level; 
  if ( gSelectL[1] == 1 ) 
  { 
  if ( (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( hitX1 / 24 + 1, 25, 1091, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24 + 1, 19, 1091, CFSTR("IWBTG.main") )] ) ) != 0 )) & (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), upDown ) ) == 0 )) ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 12; 
  hitY2 += 12; 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
 
  } 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  if ( (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pbrick" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( hitX1 / 24 + 1, 25, 1117, CFSTR("IWBTG.main") )][ChkBounds( hitY2 / 24 + 1, 19, 1117, CFSTR("IWBTG.main") )] ) ) != 0 )) & (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), upDown ) ) == 0 )) ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 12; 
  hitY2 += 12; 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), lastDir )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid LEFT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
 
  } 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  loopCycle++; 
  if ( loopCycle == 2 ) 
  { 
  loopCycle = 0; 
  PSstrcpy( inkey, FBInkey() ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), inkey ) ) != 0  ) 
  { 
  PSstrcpy( inkeyFill, "\pyup" ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), inkey )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\p " ) ) == 0 ) 
  { 
  jumpNo += 1; 
  if ( jumpNo <= 2 ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pup" ); 
  if ( jumpNo == 1 ) 
  { 
  tempJump = hitY1; 
  } 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pa" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pd" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pm" ) ) == 0 ) 
  { 
  GOSUB bullet_123; 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  } 
  } 
  } 
  else 
  { 
  if ( (-(hitY1 <= 0)) & (-(level == 1)) ) 
  { 
  level = 2; 
  hitX1 = 144; 
  hitX2 = 168; 
  hitY1 = 408; 
  hitY2 = 432; 
  GOSUB draw; 
  PSstrcpy( triggered, "\pna" ); 
  PSstrcpy( spikeGoBack1, "\pna" ); 
  PSstrcpy( spikeGoBack2, "\pna" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving1X1, spikeMoving1Y1, spikeMoving1X2, spikeMoving1Y2, 1 ); 
  FBColor( 0 ); 
  FBBox( spikeMoving2X1, spikeMoving2Y1, spikeMoving2X2, spikeMoving2Y2, 1 ); 
  } 
  if ( (-(hitY2 >= 450)) & (-(level == 2)) ) 
  { 
  level = 1; 
  hitX1 = 25; 
  hitX2 = 48; 
  hitY1 = 49; 
  hitY2 = 72; 
  GOSUB draw; 
  PSstrcpy( triggered, "\pna" ); 
  PSstrcpy( spikeGoBack1, "\pna" ); 
  PSstrcpy( spikeGoBack2, "\pna" ); 
  FBColor( 0 ); 
  FBBox( spikeMoving1X1, spikeMoving1Y1, spikeMoving1X2, spikeMoving1Y2, 1 ); 
  FBColor( 0 ); 
  FBBox( spikeMoving2X1, spikeMoving2Y1, spikeMoving2X2, spikeMoving2Y2, 1 ); 
  } 
  } 
  if ( level == 1 ) 
  { 
  activeCounter++; 
  if ( active1 == true ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save GREEN.png" ), (void*)&r ); 
  FBPicture( &(Rect){24, 2 * 24, 2 * 24, 3 * 24}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  if ( active2 == true ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save GREEN.png" ), (void*)&r ); 
  FBPicture( &(Rect){13 * 24, 2 * 24, 14 * 24, 3 * 24}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  if ( activeCounter == 80 ) 
  { 
  active1 = false; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save RED.png" ), (void*)&r ); 
  FBPicture( &(Rect){24, 2 * 24, 2 * 24, 3 * 24}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  active2 = false; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save RED.png" ), (void*)&r ); 
  FBPicture( &(Rect){13 * 24, 2 * 24, 14 * 24, 3 * 24}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  activeCounter = 0; 
  } 
  } 
  } 
  while ( !(  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pover" ),  PSstrcpy( STACK_PUSH(), game ) ) == 0  ) ); 
  FBStopMsg( PSstrcpy( STACK_PUSH(), "\pStop"), 1265 ); 
green:; 
  if ( (-(hitY1 < 300)) & (-(active1 == false)) ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save GREEN.png" ), (void*)&r ); 
  FBPicture( &(Rect){24, 2 * 24, 2 * 24, 3 * 24}, (void*)pictH ); 
  spawnLocX1 = hitX1; 
  spawnLocX2 = hitX2; 
  spawnLocY1 = hitY1; 
  spawnLocY2 = hitY2; 
  active1 = true; 
  FBOpenOutput( 3, (void*)2, &fPath3 ); 
  FBWriteSwapShort( spawnLocX1, 3 ); 
  FBWriteSwapShort( spawnLocX2, 3 ); 
  FBWriteSwapShort( spawnLocY1, 3 ); 
  FBWriteSwapShort( spawnLocY2, 3 ); 
  FBClose( 3 ); 
  } 
  if ( (-(hitY1 > 300)) & (-(active2 == false)) ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save GREEN.png" ), (void*)&r ); 
  FBPicture( &(Rect){13 * 24, 2 * 24, 14 * 24, 3 * 24}, (void*)pictH ); 
  spawnLocX1 = hitX1; 
  spawnLocX2 = hitX2; 
  spawnLocY1 = hitY1; 
  spawnLocY2 = hitY2; 
  active2 = true; 
  FBOpenOutput( 3, (void*)2, &fPath3 ); 
  FBWriteSwapShort( spawnLocX1, 3 ); 
  FBWriteSwapShort( spawnLocX2, 3 ); 
  FBWriteSwapShort( spawnLocY1, 3 ); 
  FBWriteSwapShort( spawnLocY2, 3 ); 
  FBClose( 3 ); 
  } 
  DisposeH( (void*)&pictH ); 
  RETURN_FROM_GOSUB; 
bullet_123:; 
  if ( bul1X == 0 ) 
  { 
  bul1X = hitX1; 
  bul1Y = (hitY1 + hitY2) / 2; 
  RETURN_FROM_GOSUB; 
  } 
  if ( (-(bul1X != 0)) & (-(bul2X == 0)) ) 
  { 
  bul2X = hitX1; 
  bul2Y = (hitY1 + hitY2) / 2; 
  RETURN_FROM_GOSUB; 
  } 
  if ( (-(bul1X != 0)) & ((-(bul2X != 0)) & (-(bul3X == 0))) ) 
  { 
  bul3X = hitX1; 
  bul3Y = (hitY1 + hitY2) / 2; 
  RETURN_FROM_GOSUB; 
  } 
  RETURN_FROM_GOSUB; 
draw:; 
  Cls();  
  for ( index2  = 1; index2 <= 19; index2++ )  { 
 
  for ( index1  = 1; index1 <= 25; index1++ )  { 
 
  gSelectL[1] = level; 
  if ( gSelectL[1] == 1 ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( index1, 25, 1331, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 1331, CFSTR("IWBTG.main") )] )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pbrick" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\psave-" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save RED.png" ), (void*)&r ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\papple" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Apple.png" ), (void*)&r ); 
  } 
 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pair--" ),  PSstrcpy( STACK_PUSH(), blocks1[ChkBounds( index1, 25, 1347, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 1347, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBPicture( &(Rect){(index2 - 1) * 24, (index1 - 1) * 24, ((index2 - 1) * 24) + 25, ((index1 - 1) * 24) + 25}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
 
  PSstrcpy( gSelectS[2], PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( index1, 25, 1353, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 1353, CFSTR("IWBTG.main") )] )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\pbrick" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Dirt block.png" ), (void*)&r ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\psave-" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Save RED.png" ), (void*)&r ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[2]), PSstrcpy( STACK_PUSH(), "\papple" ) ) == 0 ) 
  { 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "Apple.png" ), (void*)&r ); 
  } 
 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pair--" ),  PSstrcpy( STACK_PUSH(), blocks2[ChkBounds( index1, 25, 1369, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 1369, CFSTR("IWBTG.main") )] ) ) != 0  ) 
  { 
  FBPicture( &(Rect){(index2 - 1) * 24, (index1 - 1) * 24, ((index2 - 1) * 24) + 25, ((index1 - 1) * 24) + 25}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  } 
 
  } 
  } 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.png" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  RETURN_FROM_GOSUB; 
suck:; 
  FBLongColor( (179 * 257),(192 * 257),(196 * 257),-1 ); 
  FBText( -1, 50, -1, 36 ); 
  MoveTo( 135, 200 );   FBPrintString( PSstrcpy( STACK_PUSH(), "\pWow, you suck" ) );  PrintCR(); 
  FBText( -1, 30, -1, 36 ); 
  MoveTo( 160, 300 );   FBPrintString( PSstrcpy( STACK_PUSH(), "\pPress r to respawn" ) );  PrintCR(); 
 
  do 
  { 
  PSstrcpy( inkey, FBInkey() ); 
  } 
  while ( !(  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pr" ),  PSstrcpy( STACK_PUSH(), inkey ) ) == 0  ) ); 
  GOSUB draw; 
  RETURN_FROM_GOSUB; 
  return 0; 
} 
  

