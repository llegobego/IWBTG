#ifndef H1_ADDING_SAVE_TO_OG_MAIN_ADDING_SAVE_TO_OG
#define H1_ADDING_SAVE_TO_OG_MAIN_ADDING_SAVE_TO_OG

#import <AppKit/AppKit.h>
#include "FBtoC.h"
#include "Runtime.h"
#include  "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//  prototypes + translated #defines and records //
///////////////////////////////////////////////////
Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
;
extern Handle            pictH; 
extern Rect              r; 
extern Str255            lastDir; 
extern short             hitX1; 
extern short             hitY1; 
extern short             hitX2; 
extern short             hitY2; 
extern short             distanceCheck; 
extern short             randInt; 
extern Str255            inkey; 
extern short             heightCounter; 
extern Str255            inkeyFill; 
extern Str255            upDown; 
extern Str255            game; 
extern short             score; 
extern short             loopCycle; 
extern Str255            scoreCheck; 
extern Str255            leftRight; 
extern short             jumpNo; 
extern short             tempJump; 
extern short             index1; 
extern short             index2; 
extern Str255            blocks1[26][20]; 
extern Str255            blocks2[26][20]; 
extern Str255            object; 
extern CFURLRef          fPath; 
extern CFURLRef          fPath2; 
extern CFURLRef          fPath3; 
extern FBBoolean         active1; 
extern FBBoolean         active2; 
extern short             activeCounter; 
extern FBBoolean         firstTime; 
extern short             bul1X; 
extern short             bul1Y; 
extern short             bul2X; 
extern short             bul2Y; 
extern short             bul3X; 
extern short             bul3Y; 
extern Str255            bulDir1; 
extern Str255            bulDir2; 
extern Str255            bulDir3; 
extern Str255            bul1Flag; 
extern Str255            hitBrickX; 
extern Str255            hitBrickY; 
extern Str255            prevCheck; 
extern short             replacementBlockX1; 
extern short             replacementBlockX2; 
extern short             replacementBlockY1; 
extern short             replacementBlockY2; 
extern short             level; 
extern Str255            spikeMoving; 
extern short             spikeMoving1X1; 
extern short             spikeMoving1X2; 
extern short             spikeMoving1Y1; 
extern short             spikeMoving1Y2; 
extern short             spikeMoving2X1; 
extern short             spikeMoving2X2; 
extern short             spikeMoving2Y1; 
extern short             spikeMoving2Y2; 
extern short             spikeMoving3X1; 
extern short             spikeMoving3X2; 
extern short             spikeMoving3Y1; 
extern short             spikeMoving3Y2; 
extern Str255            triggered; 
extern Str255            spikeGoBack1; 
extern Str255            spikeGoBack2; 
extern Str255            spikeGoBack3; 
extern short             moveBackDelay1; 
extern short             moveBackDelay2; 
extern short             moveBackDelay3; 
extern Str255            death; 
extern short             spawnLocX1; 
extern short             spawnLocX2; 
extern short             spawnLocY1; 
extern short             spawnLocY2; 
extern short             currenttriggerY; 


#endif /* H1_ADDING_SAVE_TO_OG_MAIN_ADDING_SAVE_TO_OG */
