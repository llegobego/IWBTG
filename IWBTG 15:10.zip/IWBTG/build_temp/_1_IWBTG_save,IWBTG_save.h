#ifndef H1_IWBTG_SAVE_IWBTG_SAVE
#define H1_IWBTG_SAVE_IWBTG_SAVE

#import <AppKit/AppKit.h>
#include "FBtoC.h"
#include "Runtime.h"
#include  "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//  prototypes + translated #defines and records //
///////////////////////////////////////////////////
extern short             index1; 
extern short             index2; 
extern Str255            blocks[26][20]; 
extern Str255            object; 
extern CFURLRef          fPath; 
extern Str255            enter; 


#endif /* H1_IWBTG_SAVE_IWBTG_SAVE */
