#ifndef H1_IWBTG_MAIN_IWBTG
#define H1_IWBTG_MAIN_IWBTG

#import <AppKit/AppKit.h>
#include "FBtoC.h"
#include "Runtime.h"
#include  "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//  prototypes + translated #defines and records //
///////////////////////////////////////////////////
Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
;
extern Handle            pictH; 
extern Rect              r; 
extern short             hitX1; 
extern short             hitY1; 
extern short             hitX2; 
extern short             hitY2; 
extern short             distanceCheck; 
extern short             randInt; 
extern Str255            inkey; 
extern short             heightCounter; 
extern Str255            inkeyFill; 
extern Str255            upDown; 
extern Str255            game; 
extern short             score; 
extern short             int3; 
extern Str255            scoreCheck; 
extern Str255            leftRight; 
extern short             jumpNo; 
extern short             tempJump; 


#endif /* H1_IWBTG_MAIN_IWBTG */
