#include "_1_IWBTG.main,IWBTG.h"
#include "ArrayIndices.h"

#include "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//       translated globals and fns              //
///////////////////////////////////////////////////
 


Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
{
  GraphicsImportComponent gi; 
  ComponentResult   result; 
  PicHandle         pictH; 
  pictH = NULL; 
  CFURLRef          url; 
  FSRef             fsRef; 
  FSSpec            fsSpec; 
  OSErr             err; 
  FBBoolean         success; 
  url = CFBundleCopyResourceURL( CFBundleGetMainBundle(), imageName, NULL, NULL ); 
  if ( url ) 
  { 
  success = CFURLGetFSRef( url, (void*)&fsRef ); 
  CFRelease( url ); 
  if ( success ) 
  { 
  err = FSGetCatalogInfo( (void*)&fsRef, 0, NULL, NULL, &fsSpec, NULL ); 
  if ( err == noErr ) 
  { 
  err = GetGraphicsImporterForFile( (void*)&fsSpec, (void*)&gi ); 
  if ( err == noErr ) 
  { 
  result = GraphicsImportGetAsPicture( gi, (void*)&pictH ); 
  result = GraphicsImportGetBoundsRect( gi, imageRect ); 
  err = CloseComponent( gi ); 
  } 
  } 
  } 
  } 
  return (Handle)pictH; 
}  
  
Handle            pictH; 
Rect              r; 
short             hitX1; 
short             hitY1; 
short             hitX2; 
short             hitY2; 
short             distanceCheck; 
short             randInt; 
Str255            inkey; 
short             heightCounter; 
Str255            inkeyFill; 
Str255            upDown; 
Str255            game; 
short             score; 
short             int3; 
Str255            scoreCheck; 
Str255            leftRight; 
short             jumpNo; 
short             tempJump; 
short             index1; 
short             index2; 
Str255            blocks[26][20]; 
Str255            object; 
CFURLRef          fPath; 

///////////////////////////////////////////////////
//            translated main code               //
///////////////////////////////////////////////////
int main( int argc, const char * argv[] ) 
{ 
  InitFBGlobals(); 
  FBWindow( 1, CFSTR( "IWBTG" ), (struct CGRect){ { (double)0, (double)0 }, { ((double)500)- ((double)0), ((double)500)- ((double)0) } }, 0, &(int){-1} ); 
  fPath = (void*)OSpanelOpen( 0, CFSTR( "Select a file" ), CFSTR( "txt" ), CFSTR( "Open" ), NULL ); 
  FBOpenInput( 1, (void*)2, &fPath, 256, false ); 
 
  for ( index2  = 1; index2 <= 19; index2++ )  { 
 
  for ( index1  = 1; index1 <= 19; index1++ )  { 
  FBReadString( 1, (char*)&object, 5 );  
  TRUNCATE( (void*)&object ); 
  PSstrcpy( blocks[ChkBounds( index1, 25, 91, CFSTR("IWBTG.main") )][ChkBounds( index2, 19, 91, CFSTR("IWBTG.main") )], object ); 
  } 
  } 
  FBClose( 1 ); 
  hitX1 = 60; 
  hitX2 = 84; 
  hitY1 = 379; 
  hitY2 = 400; 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.gif" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
 
  do 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), upDown )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pup" ) ) == 0 ) 
  { 
 
  gSelectL[2] = jumpNo; 
  if ( gSelectL[2] == 1 ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 7; 
  hitY2 -= 7; 
  heightCounter += 1; 
  if ( heightCounter == 12 ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid UP.gif" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( gSelectL[2] == 2 ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 -= 7; 
  hitY2 -= 7; 
  heightCounter += 1; 
  if ( heightCounter == 8 ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  } 
 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pdown" ) ) == 0 ) 
  { 
  if ( jumpNo == 1 ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 7; 
  hitY2 += 7; 
  if ( hitY1 == tempJump ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  if ( (-(jumpNo == 2)) & (-(hitY1 < tempJump)) ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitY1 += 7; 
  hitY2 += 7; 
  if ( hitY1 == tempJump ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  } 
 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), leftRight )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 -= 20; 
  hitX2 -= 20; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid LEFT.gif" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  hitX1 += 20; 
  hitX2 += 20; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  pictH = (void*)ResourceImageToPICTHandle( CFSTR( "The kid RIGHT.gif" ), (void*)&r ); 
  FBPicture( &(Rect){hitY1, hitX1, hitY2, hitX2}, (void*)pictH ); 
  DisposeH( (void*)&pictH ); 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  int3++; 
  if ( int3 == 2 ) 
  { 
  int3 = 0; 
  PSstrcpy( inkey, FBInkey() ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), inkey ) ) != 0  ) 
  { 
  PSstrcpy( inkeyFill, "\pyup" ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), inkey )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\p " ) ) == 0 ) 
  { 
  if ( jumpNo < 2 ) 
  { 
  PSstrcpy( upDown, "\pup" ); 
  jumpNo += 1; 
  if ( jumpNo == 1 ) 
  { 
  tempJump = hitY1; 
  } 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pa" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pd" ); 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  } 
  } 
  } 
  while ( !(  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pover" ),  PSstrcpy( STACK_PUSH(), game ) ) == 0  ) ); 
  FBStopMsg( PSstrcpy( STACK_PUSH(), "\pStop"), 265 ); 
  return 0; 
} 
  

