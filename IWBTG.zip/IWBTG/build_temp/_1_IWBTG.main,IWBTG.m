#include "_1_IWBTG.main,IWBTG.h"
#include "ArrayIndices.h"

#include "_0_TranslatedRuntime.h"

///////////////////////////////////////////////////
//       translated globals and fns              //
///////////////////////////////////////////////////
 


Handle  ResourceImageToPICTHandle( CFStringRef imageName, Rect * imageRect ) 
{
  GraphicsImportComponent gi; 
  ComponentResult   result; 
  PicHandle         pictH; 
  pictH = NULL; 
  CFURLRef          url; 
  FSRef             fsRef; 
  FSSpec            fsSpec; 
  OSErr             err; 
  FBBoolean         success; 
  url = CFBundleCopyResourceURL( CFBundleGetMainBundle(), imageName, NULL, NULL ); 
  if ( url ) 
  { 
  success = CFURLGetFSRef( url, (void*)&fsRef ); 
  CFRelease( url ); 
  if ( success ) 
  { 
  err = FSGetCatalogInfo( (void*)&fsRef, 0, NULL, NULL, &fsSpec, NULL ); 
  if ( err == noErr ) 
  { 
  err = GetGraphicsImporterForFile( (void*)&fsSpec, (void*)&gi ); 
  if ( err == noErr ) 
  { 
  result = GraphicsImportGetAsPicture( gi, (void*)&pictH ); 
  result = GraphicsImportGetBoundsRect( gi, imageRect ); 
  err = CloseComponent( gi ); 
  } 
  } 
  } 
  } 
  return (Handle)pictH; 
}  
  
Handle            pictH; 
Rect              r; 
short             hitX1; 
short             hitY1; 
short             hitX2; 
short             hitY2; 
short             distanceCheck; 
short             randInt; 
Str255            inkey; 
short             heightCounter; 
Str255            inkeyFill; 
Str255            upDown; 
Str255            game; 
short             score; 
short             int3; 
Str255            scoreCheck; 
Str255            leftRight; 
short             jumpNo; 
short             tempJump; 

///////////////////////////////////////////////////
//            translated main code               //
///////////////////////////////////////////////////
int main( int argc, const char * argv[] ) 
{ 
  InitFBGlobals(); 
  FBWindow( 1, CFSTR( "IWBTG" ), (struct CGRect){ { (double)0, (double)0 }, { ((double)500)- ((double)0), ((double)500)- ((double)0) } }, 0, &(int){-1} ); 
  hitX1 = 60; 
  hitX2 = 80; 
  hitY1 = 380; 
  hitY2 = 400; 
 
  do 
  { 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), upDown )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pup" ) ) == 0 ) 
  { 
  hitY1 -= 5; 
  hitY2 -= 5; 
  heightCounter += 1; 
  if ( heightCounter == 20 ) 
  { 
  heightCounter = 0; 
  PSstrcpy( upDown, "\pdown" ); 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pdown" ) ) == 0 ) 
  { 
  if ( jumpNo == 1 ) 
  { 
  hitY1 += 5; 
  hitY2 += 5; 
  if ( hitY1 == tempJump ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  if ( (-(jumpNo == 2)) & (-(hitY1 < tempJump)) ) 
  { 
  hitY1 += 5; 
  hitY2 += 5; 
  if ( hitY1 == tempJump ) 
  { 
  PSstrcpy( upDown, "\p" ); 
  PSstrcpy( inkeyFill, "\p" ); 
  jumpNo = 0; 
  } 
  } 
  } 
 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), leftRight )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  hitX1 -= 20; 
  hitX2 -= 20; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  hitX1 += 20; 
  hitX2 += 20; 
  PSstrcpy( inkeyFill, "\p" ); 
  PSstrcpy( leftRight, "\p" ); 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  FBColor( 4 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  int3++; 
  if ( int3 == 2 ) 
  { 
  int3 = 0; 
  PSstrcpy( inkey, FBInkey() ); 
  if (  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\p" ),  PSstrcpy( STACK_PUSH(), inkey ) ) != 0  ) 
  { 
  PSstrcpy( inkeyFill, "\pyup" ); 
 
  PSstrcpy( gSelectS[1], PSstrcpy( STACK_PUSH(), inkey )); gFBStk--; 
  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\p " ) ) == 0 ) 
  { 
  if ( jumpNo < 2 ) 
  { 
  PSstrcpy( upDown, "\pup" ); 
  jumpNo += 1; 
  if ( jumpNo == 1 ) 
  { 
  tempJump = hitY1; 
  } 
  } 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pa" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pa" ); 
  } 
  else  if ( FBPopCmpStr( PSstrcpy( STACK_PUSH(), gSelectS[1]), PSstrcpy( STACK_PUSH(), "\pd" ) ) == 0 ) 
  { 
  PSstrcpy( leftRight, "\pd" ); 
  } 
 
  PSstrcpy( inkey, "\p" ); 
  } 
  } 
  FBColor( 0 ); 
  FBBox( hitX1, hitY1, hitX2, hitY2, 1 ); 
  } 
  while ( !(  FBPopCmpStr( PSstrcpy( STACK_PUSH(), "\pover" ),  PSstrcpy( STACK_PUSH(), game ) ) == 0  ) ); 
  FBStopMsg( PSstrcpy( STACK_PUSH(), "\pStop"), 179 ); 
  return 0; 
} 
  

