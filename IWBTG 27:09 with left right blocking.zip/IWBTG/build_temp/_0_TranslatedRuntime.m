#include "_0_TranslatedRuntime.h"
#include "FBtoC.h"
#include "General.c"
#include "Containers.c"
#include "FileHandling.c"
#include "Index.c"
#include "AppThings.c"
#include "AppThings.m"
#include "EditFields.c"
#include "FilesDollarFunction.c"
#include "Prefs.c"
#include "FileHandlingUtils.m"
#include "OSPanel.m"
#include "CocoaUI.m"
#include "ArrayIndices.h"

///////////////////////////////////////////////////
//       translated globals and fns              //
///////////////////////////////////////////////////
 

 
long  FBInstallAEHandler( long aeClass, long aeType, void* aeProc, SRefCon x, FBBoolean y ) 
{
  OSErr             err; 
  err = AEInstallEventHandler( aeClass, aeType, aeProc, x, y ); 
  return err; 
}  
  
 
 
long  Date2Secs( void* recPtr ) 
{
  unsigned long     seconds; 
  DateToSeconds( recPtr, (void*)&seconds ); 
  return seconds; 
}  
  
 
///_createMovieFileDeleteCurFile      = &80000000

///_createMovieFileDontCreateMovie    = &40000000

///_createMovieFileDontOpenFile       = &20000000




CFStringRef  CFStr( Str255 s_p ) 
{
  Str255 s;  PSstrcpy( s, s_p ); 
  gFBStk -= 1; 
  static Handle            sCFSTRh; 
  UInt32            j; 
  CFSTRRec          tempCFSTRRec; 
  void*             p; 
  void*             pp; 
  void*             ss; 
  long              lenEntry; 
  long              i; 
  CFStringRef       cfStrg; 
  if ( sCFSTRh == 0 ) 
  { 
  sCFSTRh = (void*)NewHandleClear( 4 ); 
  } 
  p = (void*)*(long*)(sCFSTRh); 
  j = *(long*)p; 
  p += 8; 
 
  while ( j ) 
  { 
  pp = p; 
  ss = (void*)&s; 
  lenEntry = *(unsigned char*)p; 
  i = lenEntry; 
 
  do 
  { 
  if ( *(unsigned char*)pp != *(unsigned char*)ss ) 
  { 
  goto cfstr; 
  } 
  pp++; 
  ss++; 
  i--; 
  } 
  while ( !( i < 0 ) ); 
  p -= 4; 
  cfStrg = (void*)*(long*)p; 
  goto LL0; 
cfstr:; 
  p = lenEntry + 5 + p; 
  j--; 
  } 
  cfStrg = CFStringCreateWithPascalString( NULL, s, kCFStringEncodingMacRoman ); 
  if ( cfStrg ) 
  { 
  tempCFSTRRec.cfStr = cfStrg; 
  PSstrcpy( tempCFSTRRec.s, s ); 
  if ( PtrAndHand( (void*)&tempCFSTRRec, sCFSTRh, s[0] + 5 ) ) 
  { 
 FBShutdown((void *)CFSTR( "Out of memory in CFSTR" ), true ); 
  } 
  p = (void*)*(long*)(sCFSTRh); 
  *(long*)p = *(long*)p + 1; 
  } 
  else 
  { 
 FBShutdown((void *)CFSTR( "CFStringCreateWithPascalString failed in CFSTR" ), true ); 
  } 
LL0:; 
  return cfStrg; 
}  
  
 
///^FSSpecPtr

///^AppParametersPtr

///_kControlSupportsNewMessages       = _"ok"

///toolbox fn GetThemeFont(ThemeFontID,@str255,int,int) = OSStatus 'Date { 2/3/02 }

 
long  FBPStr2CStr( void* strPtr ) 
{
  long              strlen; 
  strlen = *(unsigned char*)(strPtr); 
  BlockMoveData( (void*)strPtr + 1, (void*)strPtr, strlen ); 
  *(char*)( strPtr + strlen ) = 0; 
  return 0; 
}  
  
 
long  FBCStr2PStr( void* strPtr ) 
{
  void*             p; 
  long              strlen; 
  strlen = 0; 
  p = strPtr; 
 
  while ( *(unsigned char*)p ) 
  { 
  p++; 
  strlen++; 
  } 
  if ( strlen > 255 ) 
  { 
  strlen = 255; 
  } 
  BlockMoveData( strPtr, strPtr + 1, strlen ); 
  *(unsigned char*)strPtr = strlen; 
  return 0; 
}  
  
 
long  FBDoTab( long tabNum ) 
{
  tabNum -= Pos( 0 ); 
  if ( (-(tabNum > 0)) & (-(tabNum < 1024)) ) 
  { 
  FBPrintString( PSstrcpy( STACK_PUSH(), PSstring( tabNum, 32 ) ) );  } 
  return 0; 
}  
  
SInt8             gFBUpperChar[256]; 
SInt8             gFBLowerChar[256]; 
 
long  InitFBGlobals() 
{
  SInt32            j; 
for( j = 0; j < 256; j++ ) {
#if NO_SUFFIX_ON_ARRAY_NAMES
gFBUpperChar[j] = toupper( j );
gFBLowerChar[j] = tolower( j );
#else
gFBUpperChar_A[j] = toupper( j );
gFBLowerChar_A[j] = tolower( j );
#endif
}
#ifndef DECARBONATE
 

  for ( j  = 0; j <= 255; j++ )  { 
  gFBUpperChar[ChkBounds( j, 255, 69, CFSTR("Subs Compiler.incl") )] = j; 
  gFBLowerChar[ChkBounds( j, 255, 70, CFSTR("Subs Compiler.incl") )] = j; 
  } 
  UppercaseText( (void*)&gFBUpperChar[ChkBounds( 0, 255, 72, CFSTR("Subs Compiler.incl") )], 256, -2 ); 
  LowercaseText( (void*)&gFBLowerChar[ChkBounds( 0, 255, 73, CFSTR("Subs Compiler.incl") )], 256, -2 ); 
  gFBWidthLprint = -1; 
sranddev(); // randomize at startup
#if !__LP64__
//FBInitDefaultFolderRef();
FBInitAEEvents();
GetPort( &gFBBadPort );
FBPRInit();
#endif
#endif
  return 0; 

}  
  
 
long  FBGetScreenRect( Rect * rectPtr ) 
{
  BitMap            screenBitmap; 
  GetQDGlobalsScreenBits( (void*)&screenBitmap ); 
  BlockMoveData( (void*)(void*)&screenBitmap.bounds, (void*)rectPtr, sizeof( Rect ) ); 
  return 0; 
}  
  
 
long  FBGetControlRect( ControlRef c, Rect * rectPtr ) 
{
  GetControlBounds( c, rectPtr ); 
  return 0; 
}  
  
 
 
WindowRef  GetWRefFromPort() 
{
  CGrafPtr          port; 
  GetPort( (void*)&port ); 
  return GetWindowFromPort( port ); 
}  
  
 
 
long  CStubInvalRect( Rect * rectPtr ) 
{
  WindowRef         w; 
  w = GetWRefFromPort(); 
  if ( w ) 
  { 
  InvalWindowRect( w, rectPtr ); 
  } 
  return 0; 
}  
  
 
 
long  CStubValidRect( Rect * rectPtr ) 
{
  WindowRef         w; 
  w = GetWRefFromPort(); 
  if ( w ) 
  { 
  ValidWindowRect( w, rectPtr ); 
  } 
  return 0; 
}  
  
 
 
long  CStubInvalRgn( RgnHandle h ) 
{
  WindowRef         w; 
  w = GetWRefFromPort(); 
  if ( w ) 
  { 
  InvalWindowRgn( w, h ); 
  } 
  return 0; 
}  
  
 
 
long  CStubValidRgn( RgnHandle h ) 
{
  WindowRef         w; 
  w = GetWRefFromPort(); 
  if ( w ) 
  { 
  ValidWindowRgn( w, h ); 
  } 
  return 0; 
}  
  
 
#ifndef DECARBONATE
ResType           gFBAEType; 
long              gFBAEEvent; 
AEDesc *          gFBAEReply; 
OSErr             gFBAEError; 
 
long  FBAEUserAppleEvent( AEDesc * theAEvent, AEDesc * replyEvent, long handlerRefCon ) 
{
  gFBAEError = 0; 
  gFBAEType = handlerRefCon; 
  gFBAEEvent = (long)( theAEvent ); 
  gFBAEReply = (void*)replyEvent; 
  return gFBAEError; 
}  
  
 
 
long  FBInstallUserAppleEvent( ResType aeClass, ResType aeType ) 
{
  long              temp; 
  SRefCon           handlerRefcon; 
  temp = aeType; 
  handlerRefcon = temp; 
  return FBInstallAEHandler( aeClass, aeType, (void*)&FBAEUserAppleEvent, handlerRefcon, false ); 
}  
  
 
long  FBAEerror( long where, OSStatus err ) 
{
  if ( err ) 
  { 
  SysBeep( 1 ); 
  } 
  return 0; 
}  
  
 
 
long  FBSendAppleEvent( ResType aeClass, ResType aeType, void* msgPtr, long msgLen, Str255 toName_p ) 
{
  Str255 toName;  PSstrcpy( toName, toName_p ); 
  gFBStk -= 1; 
  OSErr             osErr; 
  ProcessSerialNumber curPSN; 
  ProcessSerialNumber thisPSN; 
  ProcessInfoRec    processInfo; 
  Str63             processName; 
  AEDesc            myAEDesc; 
  AEDesc            ae; 
  FBBoolean         same; 
  if ( aeClass == 0 ) 
  { 
  aeClass = 1634039412; 
  } 
  if ( aeType == 0 ) 
  { 
  aeType = 'TEXT'; 
  } 
  GetCurrentProcess( (void*)&curPSN ); 
  processInfo.processInfoLength = sizeof( ProcessInfoRec ); 
  processInfo.processName = (void*)&processName; 
  processInfo.processAppSpec = (void*)0; 
  thisPSN.highLongOfPSN = 0; 
  thisPSN.lowLongOfPSN = 0; 
 
  do 
  { 
  osErr = GetNextProcess( (void*)&thisPSN ); 
  if ( osErr ) 
  { 
  goto LL1; 
  } 
  osErr = SameProcess( (void*)&curPSN, (void*)&thisPSN, (void*)&same ); 
  if ( osErr ) 
  { 
  FBAEerror( 1, osErr ); 
  goto LL1; 
  } 
  if ( same == false ) 
  { 
  osErr = GetProcessInformation( (void*)&thisPSN, (void*)&processInfo ); 
  if ( osErr ) 
  { 
  FBAEerror( 2, osErr ); 
  goto LL1; 
  } 
  if ( (-(toName[0] == 0)) | (-( FBPopCmpStr( PSstrcpy( STACK_PUSH(), processName ),  PSstrcpy( STACK_PUSH(), toName ) ) == 0 )) ) 
  { 
  osErr = AECreateDesc( 'psn ', (void*)&thisPSN, sizeof( thisPSN ), (void*)&myAEDesc ); 
  if ( osErr ) 
  { 
  FBAEerror( 3, osErr ); 
  goto LL1; 
  } 
  osErr = AECreateAppleEvent( aeClass, aeType, (void*)&myAEDesc, kAutoGenerateReturnID, kAnyTransactionID, (void*)&ae ); 
  AEDisposeDesc( (void*)&myAEDesc ); 
  if ( osErr ) 
  { 
  FBAEerror( 4, osErr ); 
  goto LL1; 
  } 
  if ( msgPtr ) 
  { 
  osErr = AEPutParamPtr( (void*)&ae, keyDirectObject, aeType, msgPtr, msgLen ); 
  if ( osErr ) 
  { 
  AEDisposeDesc( (void*)&ae ); 
  FBAEerror( 5, osErr ); 
  goto LL1; 
  } 
  } 
  AESend( (void*)&ae, NULL, kAENoReply + kAENeverInteract, 0, kAEDefaultTimeout, NULL, NULL ); 
  AEDisposeDesc( (void*)&ae ); 
  } 
  } 
  } 
  while ( !( 0 ) ); 
LL1:; 
  return 0; 
}  
  
 
long  FBRemoveAppleEvent( ResType aeClass, ResType aeType ) 
{
  return AERemoveEventHandler( aeClass, aeType, NULL, false ); 
}  
  
 
#endif
 
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <stdio.h>
CFBundleRef       gSysBundle; 

 
CFBundleRef  CreateBundleForFramework( Str255 framework_p ) 
{
  Str255 framework;  PSstrcpy( framework, framework_p ); 
  gFBStk -= 1; 
  CFBundleRef       bundle; 
  CFURLRef          baseURL; 
  CFURLRef          bundleURL; 
  CFStringRef       frameworkCFStr; 
  CFStringRef       msg; 
  OSStatus          status; 
  FSRef             frameworksFolderRef; 
  bundle = (void*)0; 
  frameworkCFStr = CFStringCreateWithPascalString( NULL, (void*)&framework, kCFStringEncodingASCII ); 
  status = FSFindFolder( kOnAppropriateDisk, 1718772077, true, (void*)&frameworksFolderRef ); 
  if ( status == noErr ) 
  { 
  baseURL = CFURLCreateFromFSRef( NULL, (void*)&frameworksFolderRef ); 
  bundleURL = CFURLCreateCopyAppendingPathComponent( NULL, baseURL, frameworkCFStr, false ); 
  if ( baseURL ) 
  { 
  CFRelease( baseURL ); 
  } 
  bundle = CFBundleCreate( NULL, bundleURL ); 
  if ( bundleURL ) 
  { 
  CFRelease( bundleURL ); 
  } 
  } 
  if ( bundle == 0 ) 
  { 
  msg = CFStringCreateWithFormat( kCFAllocatorDefault, NULL, CFSTR( "Framework bundle \"%@\" not found" ), frameworkCFStr ); 
 FBShutdown((void *)msg, true ); 
  CFRelease( msg ); 
  } 
  CFRelease( frameworkCFStr ); 
  return bundle; 
}  
  
 
void*  GetMachFunctionFromBundle( void* bndl, Str255 name_p ) 
{
  Str255 name;  PSstrcpy( name, name_p ); 
  gFBStk -= 1; 
  CFStringRef       stringRef; 
  CFStringRef       msg; 
  void*             fptr; 
  fptr = (void*)0; 
  stringRef = CFStringCreateWithPascalString( NULL, (void*)&name, kCFStringEncodingASCII ); 
  if ( stringRef ) 
  { 
  fptr = CFBundleGetFunctionPointerForName( bndl, stringRef ); 
  } 
  if ( fptr ) 
  { 
  fptr = (void*)*(long*)(fptr); 
  } 
  else 
  { 
  msg = CFStringCreateWithFormat( kCFAllocatorDefault, NULL, CFSTR( "BSD function \"%@\" not found" ), stringRef ); 
 FBShutdown((void *)msg, true ); 
  CFRelease( msg ); 
  } 
  CFRelease( stringRef ); 
  return fptr; 
}  
  
 
UInt32  DynamicNextElement( UInt8 array ) 
{
  UInt32            nextElement; 
nextElement = gFBDynArrayInfo[array].lastElem + 1;
(void)FBDynamicArray( array, nextElement ); // ensure next element is allocated ; #641 was FBGrowDynamicArray
gFBDynArrayInfo[array].lastElem = nextElement - 1; // restore
  return nextElement; 
}  
  
 
long  DynamicRemoveItems( SInt32 dynArrayNum, SInt32 first, SInt32 howMany, void* savePtr ) 
{
  SInt32            itemSize; 
  SInt32            itemCount; 
  SInt32            lastElem; 
  void*             base; 
// info from *.c runtime globals
itemSize = gFBDynArrayInfo[dynArrayNum].elemSize;
base = gFBDynArrayInfo[dynArrayNum].base;
itemCount = gFBDynArrayInfo[dynArrayNum].maxIndex;
lastElem = gFBDynArrayInfo[dynArrayNum].lastElem; // #642
  if ( (-(first < 0)) | (-(first > lastElem)) ) 
  { 
  goto LL2; 
  } 
  if ( first + howMany - 1 > lastElem ) 
  { 
  howMany = lastElem - first + 1; 
  } 
  if ( howMany > 0 ) 
  { 
gFBDynArrayInfo[dynArrayNum].lastElem -= howMany;
  if ( savePtr ) 
  { 
  BlockMoveData( base + first * itemSize, savePtr, howMany * itemSize ); 
  } 
  BlockMoveData( base + (first + howMany) * itemSize, base + first * itemSize, (itemCount - first - howMany) * itemSize ); 
  BlockZero( base + (itemCount - howMany) * itemSize, howMany * itemSize ); 
  } 
LL2:; 
  return 0; 
}  
  
 
long  DynamicInsertItems( SInt32 dynArrayNum, SInt32 where, SInt32 howMany, void* fillPtr ) 
{
  SInt32            itemSize; 
  SInt32            itemCount; 
  void*             base; 
  if ( (-(where < 0)) | (-(howMany < 0)) ) 
  { 
  goto LL3; 
  } 
// info from *.c runtime globals
itemSize = gFBDynArrayInfo[dynArrayNum].elemSize;
itemCount = gFBDynArrayInfo[dynArrayNum].maxIndex;
  if ( itemCount < where ) 
  { 
  itemCount = where; 
  } 
FBGrowDynamicArray( dynArrayNum, itemCount + howMany ); // make room
gFBDynArrayInfo[dynArrayNum].lastElem += howMany; // bump the last elem a/c to num inserted
base = gFBDynArrayInfo[dynArrayNum].base;
  BlockMoveData( base + where * itemSize, base + (where + howMany) * itemSize, (itemCount - where) * itemSize ); 
  if ( fillPtr == 0 ) 
  { 
  BlockZero( base + where * itemSize, howMany * itemSize ); 
  } 
  else 
  { 
  BlockMoveData( fillPtr, base + where * itemSize, howMany * itemSize ); 
  } 
LL3:; 
  return 0; 
}  
  
SndListResource ** gFBSndHndl; 
SndCommand        gFBSndCmd; 
SndChannelPtr     gFBSndChanPtr; 
 
long  FBSndProc( SndChannelPtr unusedChandPtr, SndCommand * unusedSndCmd ) 
{
  gFBSndBusy = false; 
  return 0; 
}  
  
 
long  FBSoundEnd() 
{
  if ( gFBSndHndl ) 
  { 
  SndDisposeChannel( gFBSndChanPtr, ZTRUE ); 
  } 
  gFBSndBusy = false; 
  return 0; 
}  
  
 
long  FBPlaySoundHandle() 
{
  if ( gFBSndHndl ) 
  { 
  gFBSndChanPtr = (void*)0; 
  SndNewChannel( (void*)&gFBSndChanPtr, 5, 0, (void*)&FBSndProc ); 
  SndPlay( gFBSndChanPtr, gFBSndHndl, ZTRUE ); 
  gFBSndCmd.cmd = 13; 
  gFBSndBusy = ZTRUE; 
  SndDoCommand( gFBSndChanPtr, (void*)&gFBSndCmd, 0 ); 
  } 
  return 0; 
}  
  
 
long  FBSoundType1( long unusedSoundType, void* soundPtr ) 
{
  Str255            tempString; 
 
  while (  gFBSndBusy  ) 
  { 
  FBDelay( 17 ); 
  } 
  FBSoundEnd(); 
  gFBSndHndl = (void*)0; 
  BlockMoveData( (void*)soundPtr, (void*)(void*)&tempString, 256 ); 
  gFBSndHndl = (void*)GetNamedResource( 'snd ', (void*)&tempString ); 
  FBPlaySoundHandle(); 
  return 0; 
}  
  
 
long  FBSound( long SoundType, long soundRef ) 
{
  short             resNum; 
 
  while (  gFBSndBusy  ) 
  { 
  FBDelay( 17 ); 
  } 
  FBSoundEnd(); 
  gFBSndHndl = (void*)0; 
 
  gSelectL[1] = SoundType; 
  if ( gSelectL[1] == 1 ) 
  { 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  gFBSndHndl = (void*)soundRef; 
  FBPlaySoundHandle(); 
  } 
  else  if ( gSelectL[1] == 3 ) 
  { 
  resNum = soundRef; 
  gFBSndHndl = (void*)GetResource( 'snd ', resNum ); 
  FBPlaySoundHandle(); 
  } 
 
  return 0; 
}  
  
 
long  FBSoundStrExpr( void* soundPtr ) 
{
  Str255            tempString; 
 
  while (  gFBSndBusy  ) 
  { 
  FBDelay( 17 ); 
  } 
  FBSoundEnd(); 
 
  if ( *(short*)(soundPtr) == 0x0300 + (unsigned char)'%' ) 
  { 
  gFBSndHndl = (void*)GetResource( 'snd ', *(short*)(soundPtr + 2) ); 
  } 
  else  if ( *(short*)(soundPtr) == 0x0500 + (unsigned char)'&' ) 
  { 
  gFBSndHndl = (void*)*(long*)(soundPtr + 2); 
  } 
  else  { 
  BlockMoveData( (void*)soundPtr, (void*)(void*)&tempString, 8 ); 
  gFBSndHndl = (void*)GetNamedResource( 'snd ', (void*)&tempString ); 
  } 
 
  FBPlaySoundHandle(); 
  return 0; 
}  
  
 
long  SoundFreqDur( long freq, long dur, long vol, long async ) 
{
  OSErr             err; 
  SndCommand        mySndCmd; 
  if ( gFBSndChanPtr ) 
  { 
  mySndCmd.cmd = 3; 
  SndDoImmediate( gFBSndChanPtr, (void*)&mySndCmd ); 
  SndDisposeChannel( gFBSndChanPtr, ZTRUE ); 
  } 
  gFBSndChanPtr = (void*)0; 
  err = SndNewChannel( (void*)&gFBSndChanPtr, 1, 0, (void*)&FBSndProc ); 
  if ( err ) 
  { 
  goto LL4; 
  } 
  gFBSndCmd.cmd = 43; 
  gFBSndCmd.param1 = ((vol << 1)); 
  gFBSndCmd.param2 = 0; 
  SndDoCommand( gFBSndChanPtr, (void*)&gFBSndCmd, async ); 
  if ( freq < 0 ) 
  { 
  freq = - freq; 
  } 
  else 
  { 
  freq = 60.0 + rint( (log( (double)freq ) - 5.56691) / 0.057762265 ); 
  } 
  gFBSndCmd.cmd = 40; 
  gFBSndCmd.param1 = dur * 33; 
  gFBSndCmd.param2 = freq; 
  err = SndDoCommand( gFBSndChanPtr, (void*)&gFBSndCmd, async ); 
  if ( err ) 
  { 
  goto LL4; 
  } 
  gFBSndCmd.cmd = 13; 
  gFBSndBusy = ZTRUE; 
  err = SndDoCommand( gFBSndChanPtr, (void*)&gFBSndCmd, async ); 
  if ( err ) 
  { 
  goto LL4; 
  } 
  if ( async == false ) 
  { 
 
  do 
  { 
  FBDelay( 17 ); 
  } 
  while ( !( gFBSndBusy == false ) ); 
  } 
LL4:; 
  return 0; 
}  
  
 
 
long  SetButtonFocus( long btnID ) 
{
  CGrafPtr          port; 
  WindowRef         w; 
  GetPort( (void*)&port ); 
  w = GetWindowFromPort( port ); 
  if ( w ) 
  { 
  SetKeyboardFocus( w, (void*)(FBButtonAmpersandFunction(btnID)), kControlEditTextPart ); 
  } 
  return 0; 
}  
  
 
long  DrawOneControlAndValidateRect( ControlRef c ) 
{
  CGrafPtr          port; 
  WindowRef         w; 
  Rect              r; 
  FBBoolean         portOK; 
  GetPort( (void*)&port ); 
  portOK = ZTRUE; 
  if ( portOK ) 
  { 
  portOK = IsValidPort( port ); 
  } 
  if ( portOK ) 
  { 
  w = GetWindowFromPort( port ); 
  DrawOneControl( c ); 
  GetControlBounds( c, (void*)&r ); 
  if ( w ) 
  { 
  ValidWindowRect( w, (void*)&r ); 
  } 
  } 
  return 0; 
}  
  
 
long  EmbedButton( long childID, long parentsID ) 
{
  OSErr             err; 
  err = EmbedControl( (void*)(FBButtonAmpersandFunction(childID)), (void*)(FBButtonAmpersandFunction(parentsID)) ); 
  if ( err ) 
  { 
  (gFBTStkP = 0, RuntimeErrMsg( (PSstrcpy( gFBTStk[++gFBTStkP], "\pEmbedButton error " ), PSstrcat( gFBTStk[gFBTStkP], PSstr( err ) ), PSstrcat( gFBTStk[gFBTStkP], "\p for button" ), PSstrcat( gFBTStk[gFBTStkP], PSstr( childID ) ), PSstrcat( gFBTStk[gFBTStkP], "\p in" ), PSstrcat( gFBTStk[gFBTStkP], PSstr( parentsID ) )) )); 
  } 
  return 0; 
}  
  
 
long  SetButtonData( long btnID, short part, ResType tagName, long size, void* dPtr ) 
{
  ControlRef        c; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  SetControlData( c, part, tagName, size, dPtr ); 
  DrawOneControlAndValidateRect( c ); 
  } 
  return 0; 
}  
  
 
long  SetButtonTextString( long btnID, Str255 s_p ) 
{
  Str255 s;  PSstrcpy( s, s_p ); 
  gFBStk -= 1; 
  ControlRef        c; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  SetControlData( c, kControlEditTextPart, kControlEditTextTextTag, s[0], (void*)&s[1] ); 
  DrawOneControlAndValidateRect( c ); 
  } 
  return 0; 
}  
  
 
StringPtr ButtonTextString( long btnID ) 
{
  gFBStk++; 
  ControlRef        c; 
  long              actual; 
  Str255            s; 
  s[0] = 0; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  GetControlData( c, kControlEditTextPart, kControlEditTextTextTag, 255, (void*)&s[1], (void*)&actual ); 
  if ( actual < 255 ) 
  { 
  s[0] = actual; 
  } 
  else 
  { 
  s[0] = 255; 
  } 
  } 
  gFBStk--; 
  return PSstrcpy( gReturnedString, s ); 
}  
  
 
long  GetButtonData( long btnID, short part, ResType tagName, long maxSize, void* dPtr, long * actSize ) 
{
  ControlRef        c; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  GetControlData( c, part, tagName, maxSize, dPtr, actSize ); 
  } 
  return 0; 
}  
  
 
long  ButtonDataSize( long btnID, short part, ResType tagName ) 
{
  ControlRef        c; 
  long              actSize; 
  actSize = 0; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  GetControlDataSize( c, part, tagName, (void*)&actSize ); 
  } 
  return actSize; 
}  
  
 
long  SetButtonTextSelection( long btnID, short selStart, short selEnd ) 
{
  ControlRef        c; 
  ControlEditTextSelectionRec selection; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  selection.selStart = selStart; 
  selection.selEnd = selEnd; 
  SetControlData( c, 0, kControlEditTextSelectionTag, sizeof( selection ), (void*)&selection ); 
  DrawOneControlAndValidateRect( c ); 
  } 
  return 0; 
}  
  
 
long  GetButtonTextSelection( long btnID, short * selStart, short * selEnd ) 
{
  ControlRef        c; 
  ControlEditTextSelectionRec selection; 
  long              actual; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  if ( selStart ) 
  { 
  if ( selEnd ) 
  { 
  GetControlData( c, 0, kControlEditTextSelectionTag, sizeof( selection ), (void*)&selection, (void*)&actual ); 
  *(short*)selStart = selection.selStart; 
  *(short*)selEnd = selection.selEnd; 
  } 
  } 
  } 
  return 0; 
}  
  
 
long  SetButtonFontStyle( long btnID, ControlFontStyleRec * cfs ) 
{
  ControlRef        c; 
  c = (void*)FBButtonAmpersandFunction(btnID); 
  if ( c ) 
  { 
  SetControlFontStyle( c, cfs ); 
  } 
  return 0; 
}  
  
 
 
long  BtnRect( Rect * rPtr, long btnNum ) 
{
  GetControlBounds( (void*)(FBButtonAmpersandFunction(btnNum)), rPtr ); 
  return 0; 
}  
  
 
ControlRef  FindFBBtnControl( WindowRef w, long butNum ) 
{
  ControlID         cID; 
  ControlRef        c; 
  c = (void*)0; 
  cID.signature = 1178746435; 
  cID.id = butNum; 
  GetControlByID( w, (void*)&cID, (void*)&c ); 
  return c; 
}  
  
 
ControlRef  FBFindEF( long efNum, long subclassUnused, WindowRef w ) 
{
  if ( w == 0 ) 
  { 
  FBGetWindow( FBWindowFunction( 1 ), &w ); 
  } 
  return FindFBBtnControl( w, efNum ); 
}  
  
Str255            gFBControlText; 



///toolbox fn IsValidWindowPtr(WindowRef) = boolean

WindowPositionMethod gNewWndPositionMethod; 
 























long  FBXInitBSDSystemFramework() 
{
  if ( gSysBundle == 0 ) 
  { 
  gSysBundle = CreateBundleForFramework( PSstrcpy( STACK_PUSH(), "\pSystem.framework" ) ); 
  } 
  return 0; 
}  
  
 
long  e_xit( SInt32 status ) 
{
_exit((int)status );
  return 0; 
}  
  
UInt16            gFBSerialPortCount; 
Str63             gFBSerialName[13]; 
Str63             gFBSerialInName[13]; 
Str63             gFBSerialOutName[13]; 
FBBoolean         gOSXSerialInited; 
 
long  FBXSerialGetSerialIterator( io_iterator_t * matchingServices ) 
{
  kern_return_t     kernResult; 
  mach_port_t       masterPort; 
  CFMutableDictionaryRef classesToMatch; 
  Str255            serviceName; 
  CFStringRef       key; 
  CFStringRef       value; 
  kernResult = IOMasterPort( 0, (void*)&masterPort ); 
  if ( 0 != kernResult ) 
  { 
  goto LL5; 
  } 
  kernResult = 5; 
  PSstrcpy( serviceName, "\pIOSerialBSDClient" ); 
  FBPStr2CStr( (void*)&serviceName ); 
  classesToMatch = IOServiceMatching( (void*)&serviceName ); 
  if ( classesToMatch == 0 ) 
  { 
  goto LL5; 
  } 
  key = (gFBTStkP = 0, CFStringCreateWithPascalString( NULL, PSstrcpy( gFBTStk[++gFBTStkP], "\pIOSerialBSDClientType" ), kCFStringEncodingASCII )); 
  value = (gFBTStkP = 0, CFStringCreateWithPascalString( NULL, PSstrcpy( gFBTStk[++gFBTStkP], "\pIOSerialStream" ), kCFStringEncodingASCII )); 
  CFDictionarySetValue( classesToMatch, key, value ); 
  CFRelease( key ); 
  CFRelease( value ); 
  kernResult = IOServiceGetMatchingServices( masterPort, classesToMatch, matchingServices ); 
LL5:; 
  return kernResult; 
}  
  
 
long  FBXSerialGetCountAndNames( io_iterator_t serialPortIterator ) 
{
  io_object_t       serialService; 
  CFTypeRef         serialNameCFStr; 
  CFTypeRef         bsdPathCFStr; 
  Str255            bsdPath; 
  Str255            serialDevName; 
  CFStringRef       key; 
  FBBoolean         result; 
  bsdPath[0] = 0; 
  serialService = IOIteratorNext( serialPortIterator ); 
 
  while ( serialService != 0 ) 
  { 
  key = (gFBTStkP = 0, CFStringCreateWithPascalString( NULL, PSstrcpy( gFBTStk[++gFBTStkP], "\pIOTTYDevice" ), kCFStringEncodingASCII )); 
  serialNameCFStr = IORegistryEntryCreateCFProperty( serialService, key, NULL, 0 ); 
  CFRelease( key ); 
  if ( serialNameCFStr ) 
  { 
  result = CFStringGetPascalString( serialNameCFStr, (void*)&serialDevName, sizeof( serialDevName ), kCFStringEncodingASCII ); 
  CFRelease( serialNameCFStr ); 
  if ( result ) 
  { 
  gFBSerialPortCount++; 
  PSstrcpyn( gFBSerialName[ChkBounds( gFBSerialPortCount, 12, 107, CFSTR("OSX SerialIO.incl") )], serialDevName, 64 ); 
  } 
  key = (gFBTStkP = 0, CFStringCreateWithPascalString( NULL, PSstrcpy( gFBTStk[++gFBTStkP], "\pIOCalloutDevice" ), kCFStringEncodingASCII )); 
  bsdPathCFStr = IORegistryEntryCreateCFProperty( serialService, key, NULL, 0 ); 
  CFRelease( key ); 
  if ( bsdPathCFStr ) 
  { 
  result = CFStringGetCString( bsdPathCFStr, (void*)&bsdPath, sizeof( bsdPath ), kCFStringEncodingASCII ); 
  CFRelease( bsdPathCFStr ); 
  if ( result ) 
  { 
  FBCStr2PStr( (void*)&bsdPath ); 
  PSstrcpyn( gFBSerialOutName[ChkBounds( gFBSerialPortCount, 12, 119, CFSTR("OSX SerialIO.incl") )], bsdPath, 64 ); 
  PSstrcpyn( gFBSerialInName[ChkBounds( gFBSerialPortCount, 12, 120, CFSTR("OSX SerialIO.incl") )], bsdPath, 64 ); 
  } 
///print " BSD path: "; : fn PrintCString( bsdPath ) : print 

  } 
  } 
  IOObjectRelease( serialService ); 
  serialService = IOIteratorNext( serialPortIterator ); 
  } 
  return 0; 
}  
  
 
long  FBXSerialSetBaud( termios * options, long speed ) 
{
 
  gSelectL[1] = (speed); 
  if ( gSelectL[1] >= 230400 ) 
  { 
  speed = 230400; 
  } 
  else  if ( gSelectL[1] >= 115200 ) 
  { 
  speed = 115200; 
  } 
  else  if ( gSelectL[1] >= 76800 ) 
  { 
  speed = 76800; 
  } 
  else  if ( gSelectL[1] >= 57600 ) 
  { 
  speed = 57600; 
  } 
  else  if ( gSelectL[1] >= 38400 ) 
  { 
  speed = 38400; 
  } 
  else  if ( gSelectL[1] >= 28800 ) 
  { 
  speed = 28800; 
  } 
  else  if ( gSelectL[1] >= 19200 ) 
  { 
  speed = 19200; 
  } 
  else  if ( gSelectL[1] >= 14400 ) 
  { 
  speed = 14400; 
  } 
  else  if ( gSelectL[1] >= 9600 ) 
  { 
  speed = 9600; 
  } 
  else  if ( gSelectL[1] >= 7200 ) 
  { 
  speed = 7200; 
  } 
  else  if ( gSelectL[1] >= 4800 ) 
  { 
  speed = 4800; 
  } 
  else  if ( gSelectL[1] >= 2400 ) 
  { 
  speed = 2400; 
  } 
  else  if ( gSelectL[1] >= 1800 ) 
  { 
  speed = 1800; 
  } 
  else  if ( gSelectL[1] >= 1200 ) 
  { 
  speed = 1200; 
  } 
  else  if ( gSelectL[1] >= 600 ) 
  { 
  speed = 600; 
  } 
  else  if ( gSelectL[1] >= 300 ) 
  { 
  speed = 300; 
  } 
  else  if ( gSelectL[1] >= 200 ) 
  { 
  speed = 200; 
  } 
  else  if ( gSelectL[1] >= 150 ) 
  { 
  speed = 150; 
  } 
  else  if ( gSelectL[1] >= 134 ) 
  { 
  speed = 134; 
  } 
  else  { 
  speed = 110; 
  } 
 
  return cfsetspeed( options, speed ); 
}  
  
 
long  FBXOpenSerialPort( Str255 path_p, long speed, long parity, long stopBits, long charSize, termios * origOptions ) 
{
  Str255 path;  PSstrcpy( path, path_p ); 
  gFBStk -= 1; 
  long              fileDescriptor; 
  termios           options; 
  Str255            pathC; 
  long              csize; 
  BlockMoveData( (void*)&path, (void*)&pathC, 256 ); 
  FBPStr2CStr( (void*)&pathC ); 
  fileDescriptor = open( (void*)&pathC, (2) | ((0) | (4)) ); 
  if ( fileDescriptor == - 1 ) 
  { 
  goto fbxopenserialport; 
  } 
  if ( fcntl( fileDescriptor, 4, 0 ) == - 1 ) 
  { 
  goto fbxopenserialport; 
  } 
  if ( tcgetattr( fileDescriptor, origOptions ) == - 1 ) 
  { 
  goto fbxopenserialport; 
  } 
  options = *origOptions; 
  cfmakeraw( (void*)&options ); 
  options.c_cflag = (options.c_cflag) | ((32768) | (2048)); 
  options.c_lflag = (options.c_lflag) & (~(2)); 
  options.c_cc[ChkBounds( 16, 19, 209, CFSTR("OSX SerialIO.incl") )] = 0; 
  options.c_cc[ChkBounds( 17, 19, 210, CFSTR("OSX SerialIO.incl") )] = 0; 
  FBXSerialSetBaud( (void*)&options, speed ); 
 
  gSelectL[1] = parity; 
  if ( gSelectL[1] == 1 ) 
  { 
  options.c_cflag = (options.c_cflag) | ((4096) | (8192)); 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  options.c_cflag = ((options.c_cflag) | (4096)) & (~(8192)); 
  } 
  else  { 
  options.c_cflag = (options.c_cflag) & (~(4096)); 
  } 
 
  if ( stopBits == 1 ) 
  { 
  options.c_cflag = (options.c_cflag) | (1024); 
  } 
  else 
  { 
  options.c_cflag = (options.c_cflag) & (~(1024)); 
  } 
 
  gSelectL[1] = charSize; 
  if ( gSelectL[1] == 2 ) 
  { 
  csize = 0; 
  } 
  else  if ( gSelectL[1] == 3 ) 
  { 
  csize = 256; 
  } 
  else  if ( gSelectL[1] == 0 ) 
  { 
  csize = 512; 
  } 
  else  { 
  csize = 768; 
  } 
 
  options.c_cflag = ((options.c_cflag) & (~(768))) | ((csize) & (768)); 
  if ( tcsetattr( fileDescriptor, 0, (void*)&options ) == - 1 ) 
  { 
  goto fbxopenserialport; 
  } 
  goto LL6; 
fbxopenserialport:; 
  if ( fileDescriptor != - 1 ) 
  { 
  close( fileDescriptor ); 
  fileDescriptor = - 1; 
  } 
LL6:; 
  return fileDescriptor; 
}  
  
 
long  FBXHandShake( long fileDescriptor, long controlMode ) 
{
  termios           options; 
  long              flags; 
  if ( fileDescriptor > 0 ) 
  { 
  if ( tcgetattr( fileDescriptor, (void*)&options ) != - 1 ) 
  { 
 
  gSelectL[1] = controlMode; 
  if ( gSelectL[1] == 0 ) 
  { 
  options.c_cflag = (options.c_cflag) & (~(196608)); 
  options.c_iflag = (options.c_iflag) & (~((512) | ((1024) | (2048)))); 
  } 
  else  if ( gSelectL[1] == 1 ) 
  { 
  options.c_cflag = (options.c_cflag) | (196608); 
  options.c_iflag = (options.c_iflag) & (~((512) | ((1024) | (2048)))); 
  } 
  else  if ( gSelectL[1] == -1 ) 
  { 
  options.c_cflag = (options.c_cflag) & (~(196608)); 
  options.c_iflag = (options.c_iflag) | ((512) | ((1024) | (2048))); 
  } 
  else  if ( gSelectL[1] == 2 ) 
  { 
  if ( ioctl( fileDescriptor, 1074033770, (void*)&flags ) != - 1 ) 
  { 
  flags = (flags) | (2); 
  ioctl( fileDescriptor, -2147191699, (void*)&flags ); 
  } 
  } 
  else  if ( gSelectL[1] == -2 ) 
  { 
  if ( ioctl( fileDescriptor, 1074033770, (void*)&flags ) != - 1 ) 
  { 
  flags = (flags) & (~(2)); 
  ioctl( fileDescriptor, -2147191699, (void*)&flags ); 
  } 
  } 
 
  tcsetattr( fileDescriptor, 0, (void*)&options ); 
  } 
  } 
  return 0; 
}  
  
 
long  FBInitSerialPorts() 
{
  io_iterator_t     serialPortIterator; 
  if ( (-(gOSXSerialInited == false)) | (-(gFBSerialPortCount == 0)) ) 
  { 
  gOSXSerialInited = ZTRUE; 
  FBXInitBSDSystemFramework(); 
  if ( FBXSerialGetSerialIterator( (void*)&serialPortIterator ) == noErr ) 
  { 
  FBXSerialGetCountAndNames( serialPortIterator ); 
  } 
  } 
  return 0; 
}  
  
 
long  FBSerialOpen( long fileRef, long baudRate, long parity, long stopBits, long charSize, long buffSize ) 
{
  long              portNum; 
  Str255            path; 
  void*             buff; 
  long              fd; 
  termios           origOptions; 
  long              i; 
  portNum = - fileRef; 
  if ( (-(portNum <= 0)) | (-(portNum > gFBSerialPortCount)) ) 
  { 
  FBCheckFileError( fileRef, -37 ); 
  goto LL7; 
  } 
  i = portNum + 256; 
  if ( gFBOpenFiles[ChkBounds( i, 267, 335, CFSTR("OSX SerialIO.incl") )].fileDescriptor ) 
  { 
  FBCheckFileError( fileRef, -47 ); 
  goto LL7; 
  } 
  FBInitSerialPorts(); 
  PSstrcpy( path, gFBSerialOutName[ChkBounds( portNum, 12, 341, CFSTR("OSX SerialIO.incl") )] ); 
  if ( buffSize < 4096 ) 
  { 
  buffSize = 4096; 
  } 
  if ( buffSize > 32768 ) 
  { 
  buffSize = 32768; 
  } 
  buff = malloc( buffSize ); 
  fd = FBXOpenSerialPort( PSstrcpy( STACK_PUSH(), path ), baudRate, parity, stopBits, charSize, (void*)&origOptions ); 
  if ( fd < 0 ) 
  { 
  free( buff ); 
  FBCheckFileError( fileRef, -36 ); 
  goto LL7; 
  } 
  gFBOpenFiles[ChkBounds( i, 267, 355, CFSTR("OSX SerialIO.incl") )].isOpen = true; 
  gFBOpenFiles[ChkBounds( i, 267, 357, CFSTR("OSX SerialIO.incl") )].buff = buff; 
  gFBOpenFiles[ChkBounds( i, 267, 358, CFSTR("OSX SerialIO.incl") )].buffSize = buffSize; 
  gFBOpenFiles[ChkBounds( i, 267, 359, CFSTR("OSX SerialIO.incl") )].fileDescriptor = fd; 
LL7:; 
  return 0; 
}  
  
 
long  FBHandShake( long fileRef, long flags ) 
{
  long              portNum; 
  long              fd; 
  portNum = - fileRef; 
  if ( (-(portNum > 0)) & (-(portNum <= gFBSerialPortCount)) ) 
  { 
  fd = gFBOpenFiles[ChkBounds( portNum + 256, 267, 370, CFSTR("OSX SerialIO.incl") )].fileDescriptor; 
  if ( fd ) 
  { 
  FBXHandShake( fd, flags ); 
  } 
  } 
  return 0; 
}  
  
 
long  TermGetStatus( long fileRef ) 
{
  long              portNum; 
  long              portStatus; 
  long              fd; 
  Str255            pathC; 
  FBInitSerialPorts(); 
  portNum = - fileRef; 
  if ( (-(portNum <= 0)) | (-(portNum > gFBSerialPortCount)) ) 
  { 
  portStatus = 3; 
  goto LL8; 
  } 
  if ( gFBOpenFiles[ChkBounds( portNum + 256, 267, 387, CFSTR("OSX SerialIO.incl") )].fileDescriptor ) 
  { 
  portStatus = 2; 
  goto LL8; 
  } 
  PSstrcpy( pathC, gFBSerialOutName[ChkBounds( portNum, 12, 392, CFSTR("OSX SerialIO.incl") )] ); 
  FBPStr2CStr( (void*)&pathC ); 
  fd = open( (void*)&pathC, (2) | ((0) | (4)) ); 
  portStatus = 0; 
  if ( fd == - 1 ) 
  { 
  portStatus = 2; 
  } 
  close( fd ); 
LL8:; 
  return portStatus; 
}  
  
 
 
long  FBGetFolderName( long DirID, short WDRefNum, void* StrPtr ) 
{
  char              pBlk[128]; BlockZero( &pBlk, sizeof( pBlk ) ); 
  PSstrcpy( ((StringPtr)StrPtr), "\p" ); 
  *(long*)(pBlk + 48) = DirID; 
  *(short*)(pBlk + 22) = WDRefNum; 
  *(long*)(pBlk + 18) = (long)( StrPtr ); 
  *(short*)(pBlk + 28) = - 1; 
  if ( PBGetCatInfoSync( (void*)&pBlk ) ) 
  { 
  PSstrcpy( ((StringPtr)StrPtr), "\pError" ); 
  } 
  return 0; 
}  
  
 
void  BlockFill( void* address, unsigned long bytes, long byteVal ) 
{
  memset( address, byteVal, bytes ); 
}  
  
 
void  LongBlockFill( void* address, unsigned long bytes, long byteVal ) 
{
  memset( address, byteVal, bytes ); 
}  
  
 
long  Handle2Btn( ControlRef c ) 
{
  ControlID         cID; 
if( GetControlID( c, &cID ) ) cID.id = 0;
  return cID.id; 
}  
  
 
void  FLASH() 
{
  CGrafPtr          port; 
  Rect              portRect; 
  GetPort( (void*)&port ); 
  GetPortBounds( port, (void*)&portRect ); 
  InvertRect( (void*)&portRect ); 
  FBFlushWindowBuffer( 0 ); 
}  
  
 
void  ORSICN( long x, long y, long rID ) 
{
  Handle            rHndl; 
  BitMap *          PortBitmapPtr; 
  Rect              src; 
  Rect              dest; 
  CGrafPtr          port; 
  BitMap            pm; 
  SetRect( (void*)&src, 0, 0, 16, 16 ); 
  dest = src; 
  OffsetRect( (void*)&dest, x, y ); 
  rHndl = (void*)GetResource( 'SICN', rID ); 
  if ( rHndl ) 
  { 
  GetPort( (void*)&port ); 
  PortBitmapPtr = (void*)GetPortBitMapForCopyBits( port ); 
  pm.baseAddr = (void*)*(long*)(rHndl); 
  pm.rowBytes = 2; 
  pm.bounds = src; 
  CopyBits( (void*)&pm, PortBitmapPtr, (void*)&src, (void*)&dest, 1, NULL ); 
  } 
  else 
  { 
  FrameRect( (void*)&dest ); 
  } 
}  
  
 
void  DisposeH( Handle * vPtr ) 
{
  Handle            h; 
  char              state; 
  h = (void*)*(long*)vPtr; 
  if ( h ) 
  { 
  state = HGetState( h ); 
  if ( (state) & (0x0020) ) 
  { 
  } 
  else 
  { 
  DisposeHandle( h ); 
  *(long*)vPtr = 0; 
  } 
  } 
}  
  
 
void  FBScroll( Rect * r, long dx, long dy ) 
{
  RgnHandle         tempRgn; 
  if ( (dx) | (dy) ) 
  { 
  tempRgn = (void*)NewRgn(); 
  ScrollRect( r, dx, dy, tempRgn ); 
  DisposeRgn( tempRgn ); 
  } 
}  
  
 
 
void  SHOWPOP( Rect * rPtr ) 
{
  long              i; 
 
  for ( i  = 0; i <= 5; i++ )  { 
  MoveTo( rPtr->right - 11 - i, rPtr->top - i + 11 ); 
  LineTo( rPtr->right - 11 + i, rPtr->top - i + 11 ); 
  } 
}  
  
 
void  CopyRect( Rect * rect1, Rect * rect2 ) 
{
  BlockMoveData( (void*)rect1, (void*)rect2, sizeof( Rect ) ); 
}  
  
 
 
long  RemoveStr( Handle strH, long oneBasedItem ) 
{
  long              count; 
  long              offset; 
  long              lgth; 
  long              shift; 
  OSStatus          err; 
  err = paramErr; 
  if ( (-(strH == 0)) | (-(oneBasedItem < 1)) ) 
  { 
  goto LL9; 
  } 
  err = 1; 
  count = *(short*)(*strH); 
  if ( count ) 
  { 
  err = 2; 
  if ( oneBasedItem <= count ) 
  { 
  err = noErr; 
  oneBasedItem--; 
  offset = 2; 
 
  while ( oneBasedItem ) 
  { 
  offset += *(unsigned char*)(*(long*)(strH) + offset) + 1; 
  oneBasedItem--; 
  } 
  lgth = *(unsigned char*)(*(long*)(strH) + offset) + 1; 
  shift = GetHandleSize( strH ) - lgth - offset; 
  BlockMoveData( (void*)(*(long*)(strH) + offset + lgth), (void*)(*(long*)(strH) + offset), shift ); 
  *(short*)(*strH) -= 1; 
  SetHandleSize( strH, GetHandleSize( strH ) - lgth ); 
  } 
  } 
LL9:; 
  return err; 
}  
  
 
void  SHADOWBOX( Rect * rectPtr ) 
{
  OffsetRect( rectPtr, - 1, - 1 ); 
  EraseRect( rectPtr ); 
  FrameRect( rectPtr ); 
  MoveTo( rectPtr->left + 4, rectPtr->bottom ); 
  LineTo( rectPtr->right, rectPtr->bottom ); 
  LineTo( rectPtr->right, rectPtr->top + 3 ); 
  OffsetRect( rectPtr, 1, 1 ); 
}  
  
 
void  CheckOneItem( long menuId, long itemId ) 
{
  MenuRef           m; 
  MenuRef           hier; 
  long              item; 
  long              count; 
  short             mark; 
  m = GetMenuHandle( menuId ); 
  if ( m ) 
  { 
  count = CountMenuItems( m ); 
  if ( count ) 
  { 
 
  for ( item  = 1; item <= count; item++ )  { 
  GetItemMark( m, item, (void*)&mark ); 
  if ( mark ) 
  { 
  hier = GetMenuHandle( mark ); 
  } 
  else 
  { 
  hier = (void*)0; 
  } 
  if ( hier == false ) 
  { 
  CheckMenuItem( m, item, (-(itemId == item)) ); 
  } 
  } 
  } 
  } 
}  
  
 
void  apndstr( Str255 t_p, Handle h ) 
{
  Str255 t;  PSstrcpy( t, t_p ); 
  gFBStk -= 1; 
  long              oldSize; 
  if ( h ) 
  { 
  oldSize = GetHandleSize( h ); 
  SetHandleSize( h, oldSize + t[0] + 1 ); 
  if ( MemError() == noErr ) 
  { 
  BlockMoveData( (void*)&t, (void*)(*(long*)(h) + oldSize), t[0] + 1 ); 
  *(short*)(*h) += 1; 
  } 
  else 
  { 
 FBShutdown((void *)CFSTR( "Failed to append \"t$\" to STR# handle." ), true ); 
  } 
  } 
}  
  
 
void  APNDLNG( long param, Handle h ) 
{
  long              oldSize; 
  if ( h ) 
  { 
  oldSize = GetHandleSize( h ); 
  SetHandleSize( h, oldSize + 4 ); 
  if ( MemError() == noErr ) 
  { 
  *(long*)( *(long*)(h) + oldSize ) = param; 
  } 
  } 
}  
  
 
void  CBOX( Rect * rPtr, void* StrPtr ) 
{
  TETextBox( StrPtr + 1, *(unsigned char*)(StrPtr), rPtr, 1 ); 
}  
  
 
void  LBOX( Rect * rPtr, void* StrPtr ) 
{
  TETextBox( StrPtr + 1, *(unsigned char*)(StrPtr), rPtr, 0 ); 
}  
  
 
void  RBOX( Rect * rPtr, void* StrPtr ) 
{
  TETextBox( StrPtr + 1, *(unsigned char*)(StrPtr), rPtr, -1 ); 
}  
  
 
void  TRUNCATE( void* StrPtr ) 
{
  UInt8             strLen; 
  strLen = *(unsigned char*)(StrPtr); 
 
  while ( (-(strLen > 0)) & (-(*(unsigned char*)(StrPtr + strLen) == (unsigned char)' ')) ) 
  { 
  strLen--; 
  } 
  *(char*)( StrPtr ) = strLen; 
}  
  
 
 
void  TITLERECT( Str255 s_p, short xOff, Rect * RectPtr ) 
{
  Str255 s;  PSstrcpy( s, s_p ); 
  gFBStk -= 1; 
  FrameRect( RectPtr ); 
  MoveTo( RectPtr->left + xOff, RectPtr->top + 4 ); 
  TextMode( 0 ); 
  DrawString( (void*)&s ); 
}  
  
 
 
long  FONTHEIGHT() 
{
  FontInfo          Font; 
  GetFontInfo( (void*)&Font ); 
  return Font.ascent + Font.descent + Font.leading; 
}  
  
 
long  ROUND( double f ) 
{
  return rint( f ); 
}  
  
 
long  roundUp( double f ) 
{
  double            ff; 
  ff = frac( f ); 
  if ( (-(ff < 0.0)) | (-(ff > 0.0)) ) 
  { 
  f += sgn( f ); 
  } 
  return trunc( f ); 
}  
  
 
long  roundDown( double f ) 
{
  return trunc( f ); 
}  
  
 
long  Wptr2WNum( WindowRef w ) 
{
  return FBGetWndNumber( w ); 
}  
  
 
long  STROFFSET( long element, long rID ) 
{
  long              offset; 
  Handle            rHndl; 
  offset = 0; 
  if ( rID >> 15 ) 
  { 
  rHndl = (void*)rID; 
  } 
  else 
  { 
  rHndl = (void*)GetResource( 'STR#', rID ); 
  } 
  if ( rHndl ) 
  { 
  offset = 2; 
  if ( element ) 
  { 
  element--; 
 
  while ( element ) 
  { 
  offset += *(unsigned char*)(*(long*)(rHndl) + offset) + 1; 
  element--; 
  } 
  } 
  } 
  return offset; 
}  
  
 
void  ChangedResourceX( Handle rH ) 
{
  if ( (HGetState( rH )) & (32) ) 
  { 
  if ( ((GetResAttrs( rH )) & (2)) != 2 ) 
  { 
  ChangedResource( rH ); 
  } 
  } 
}  
  
 

Handle  ReplaceResource( Handle rH, OSType rTp, short rID, Str255 rName_p, short rRef ) 
{
  Str255 rName;  PSstrcpy( rName, rName_p ); 
  gFBStk -= 1; 
  short             hFlags; 
  short             curRes; 
  long              size; 
  OSErr             osErr; 
  Handle            newH; 
  Handle            rOld; 
  ResType           tempResTp; 
  short             tempResID; 
  tempResTp = rTp; 
  tempResID = rID; 
  osErr = noErr; 
  if ( rH ) 
  { 
  hFlags = HGetState( rH ); 
  if ( (hFlags) & (32) ) 
  { 
  LoadResource( rH ); 
  HNoPurge( rH ); 
  newH = rH; 
  HandToHand( (void*)&newH ); 
  HSetState( rH, hFlags ); 
  rH = newH; 
  } 
  } 
  if ( rH ) 
  { 
  curRes = CurResFile(); 
  UseResFile( rRef ); 
  rOld = (void*)Get1Resource( rTp, rID ); 
  if ( rOld ) 
  { 
  hFlags = HGetState( rOld ); 
  HUnlock( rOld ); 
  HNoPurge( rOld ); 
  size = GetHandleSize( rH ); 
  SetHandleSize( rOld, size ); 
  osErr = MemError(); 
  if ( osErr ) 
  { 
  goto dump_old__add_new; 
  } 
  BlockMoveData( (void*)*(long*)(rH), (void*)*(long*)(rOld), size ); 
  HSetState( rOld, hFlags ); 
  HNoPurge( rOld ); 
  ChangedResourceX( rOld ); 
  DisposeHandle( rH ); 
  if ( PSlen( PSstrcpy( STACK_PUSH(), rName ) ) ) 
  { 
  SetResInfo( rOld, rID, (void*)&rName ); 
  } 
  } 
  else 
  { 
  SetResLoad( false ); 
  rOld = (void*)Get1Resource( rTp, rID ); 
  SetResLoad( ZTRUE ); 
dump_old__add_new:; 
  if ( rOld ) 
  { 
  if ( PSlen( PSstrcpy( STACK_PUSH(), rName ) ) == 0 ) 
  { 
  GetResInfo( rOld, (void*)&tempResID, (void*)&tempResTp, (void*)&rName ); 
  } 
  RemoveResource( rOld ); 
  DisposeH( (void*)&rOld ); 
  } 
  AddResource( rH, rTp, rID, (void*)&rName ); 
  SetResAttrs( rH, 32 + 2 ); 
  } 
  UseResFile( curRes ); 
  if ( (ResError()) | (osErr) ) 
  { 
  rH = (void*)0; 
  } 
  } 
  return rH; 
}  
  
 
 
void*  GetPict( Rect * r ) 
{
  CGrafPtr          port; 
  Picture **        pictH; 
  RgnHandle         theRgn; 
  BitMap *          PortBitmapPtr; 
  GetPort( (void*)&port ); 
  pictH = (void*)OpenPicture( r ); 
  theRgn = (void*)NewRgn(); 
  RectRgn( theRgn, r ); 
  PortBitmapPtr = (void*)GetPortBitMapForCopyBits( port ); 
  CopyBits( PortBitmapPtr, PortBitmapPtr, r, r, 0, NULL ); 
  ClosePicture(); 
  DisposeRgn( theRgn ); 
  return pictH; 
}  
  
 
 
void  LCOPY() 
{
  CGrafPtr          port; 
  Picture **        p; 
  Rect              portRect; 
  GetPort( (void*)&port ); 
  GetPortBounds( port, (void*)&portRect ); 
  p = (void*)GetPict( (void*)&portRect ); 
  if ( p ) 
  { 
  FBRoute ( 128 ); 
  DrawPicture( p, (void*)&portRect ); 
  KillPicture( p ); 
  FBRoute ( 0 ); 
  CloseLPrint(); 
  } 
  SetPort( port ); 
}  
  
 
 
void  ClearHandle( Handle h ) 
{
  long              p; 
  long              e; 
  if ( h ) 
  { 
  e = GetHandleSize( h ); 
  p = *(long*)(h); 
  e = (p + e) - 3; 
 
  while ( p < e ) 
  { 
  *(long*)( p ) = 0; 
  p = p + 4; 
  } 
  e = e + 3; 
 
  while ( p < e ) 
  { 
  *(char*)( p ) = 0; 
  p = p + 1; 
  } 
  } 
}  
  
 
void  LCASE( void* sPtr ) 
{
  void*             endAddr; 
  void*             addr; 
  addr = sPtr; 
  endAddr = *(unsigned char*)addr + addr; 
 
  while ( addr < endAddr ) 
  { 
  addr = (void*)addr + 1; 
  *(unsigned char*)addr = gFBLowerChar[ChkBounds( *(unsigned char*)addr, 255, 556, CFSTR("Subs DefUsr.incl") )]; 
  } 
}  
  
 
 
void  SmallDebugWindow( Str255 msg_p ) 
{
  Str255 msg;  PSstrcpy( msg, msg_p ); 
  gFBStk -= 1; 
  Rect              r; 
  WindowRef         wPtr; 
  CGrafPtr          port; 
  GetPort( (void*)&port ); 
 
  while ( Button() ) 
  { 
  } 
  FBGetScreenRect( (void*)&r ); 
  r.left = r.right - 256; 
  r.top = r.bottom - (4 * 12); 
  OffsetRect( (void*)&r, - 4, - 4 ); 
  wPtr = (gFBTStkP = 0, NewCWindow( NULL, (void*)&r, PSstrcpy( gFBTStk[++gFBTStkP], "\p" ), ZTRUE, 2, (void*)(- 1), false, 0 )); 
  ConstrainWindowToScreen( wPtr, kWindowStructureRgn, 2, NULL, NULL ); 
  if ( wPtr ) 
  { 
  SetPortWindowPort( wPtr ); 
  OffsetRect( (void*)&r, - r.left, - r.top ); 
  BackColor( 69 ); 
  ForeColor( 409 ); 
  EraseRect( (void*)&r ); 
  r.bottom = r.bottom - 12; 
  TextFont( 0 ); 
  TextSize( 9 ); 
  TETextBox( (void*)&msg[1], msg[0], (void*)&r, -2 ); 
  r.top = r.bottom; 
  r.bottom = r.bottom + 12; 
  PSstrcpy( msg, "\pClick mouse to continue." ); 
  TextFace( 1 ); 
  TETextBox( (void*)&msg[1], msg[0], (void*)&r, 1 ); 
  if ( QDIsPortBuffered( GetWindowPort( wPtr ) ) ) 
  { 
  QDFlushPortBuffer( GetWindowPort( wPtr ), NULL ); 
  } 
 
  do 
  { 
  FBDelay( 60 ); 
  } 
  while ( !( Button() ) ); 
 
  while ( Button() ) 
  { 
  FBDelay( 60 ); 
  } 
  DisposeWindow( wPtr ); 
  } 
  SetPort( port ); 
}  
  
 
 
void  DEBUGNUMBER( double theNum ) 
{
  Str255            msg; 
  (PSstrcpy( TO_STACK, "\pDecimal:" ), PSstrcat( TO_STACK, PSstr( theNum ) ), PSstrcat( TO_STACK, PSstring( 1, 13 ) )); PSstrcpy( msg, TO_STACK ); 
  (PSstrcpy( TO_STACK, msg ), PSstrcat( TO_STACK, "\p    Hex: " ), PSstrcat( TO_STACK, PShex( theNum ) ), PSstrcat( TO_STACK, PSstring( 1, 13 ) )); PSstrcpy( msg, TO_STACK ); 
  (PSstrcpy( TO_STACK, msg ), PSstrcat( TO_STACK, "\p Binary: " ), PSstrcat( TO_STACK, PSbin( theNum ) )); PSstrcpy( msg, TO_STACK ); 
  SmallDebugWindow( PSstrcpy( STACK_PUSH(), msg ) ); 
}  
  
 
void  DEBUGSTRING( Str255 msg_p ) 
{
  Str255 msg;  PSstrcpy( msg, msg_p ); 
  gFBStk -= 1; 
  SmallDebugWindow( PSstrcpy( STACK_PUSH(), msg ) ); 
}  
  
 
void  DEBUGRECT( Rect * r ) 
{
  Str255            s; 
  (PSstrcpy( TO_STACK, "\p   t,l,b,r:" ), PSstrcat( TO_STACK, PSstr( r->top ) ), PSstrcat( TO_STACK, "\p," ), PSstrcat( TO_STACK, PSstr( r->left ) ), PSstrcat( TO_STACK, "\p," ), PSstrcat( TO_STACK, PSstr( r->bottom ) ), PSstrcat( TO_STACK, "\p," ), PSstrcat( TO_STACK, PSstr( r->right ) ), PSstrcat( TO_STACK, PSstring( 1, 13 ) )); PSstrcpy( s, TO_STACK ); 
  (PSstrcpy( TO_STACK, "\p (l,t)-(r,b)" ), PSstrcat( TO_STACK, "\p(" ), PSstrcat( TO_STACK, PSstr( r->left ) ), PSstrcat( TO_STACK, "\p," ), PSstrcat( TO_STACK, "\p," ), PSstrcat( TO_STACK, PSstr( r->top ) ), PSstrcat( TO_STACK, "\p)-(" ), PSstrcat( TO_STACK, PSstr( r->right ) ), PSstrcat( TO_STACK, "\p," ), PSstrcat( TO_STACK, PSstr( r->bottom ) ), PSstrcat( TO_STACK, "\p)" ), PSstrcat( TO_STACK, PSstring( 1, 13 ) )); PSstrcat( s, TO_STACK ); 
  (PSstrcpy( TO_STACK, "\p      width:" ), PSstrcat( TO_STACK, PSstr( r->right - r->left ) ), PSstrcat( TO_STACK, "\p height:" ), PSstrcat( TO_STACK, PSstr( r->bottom - r->top ) )); PSstrcat( s, TO_STACK ); 
  SmallDebugWindow( PSstrcpy( STACK_PUSH(), s ) ); 
}  
  
 
void  SetWindowBackground( RGBColor * inBackRGB, FBBoolean applyNow ) 
{
  WindowRef         w; 
  CGrafPtr          port; 
  RGBColor *        backRGB; 
  FBBoolean         portOK; 
  ThemeBrush        brush; 
  GetPort( (void*)&port ); 
  portOK = IsValidPort( port ); 
  if ( portOK ) 
  { 
  w = GetWindowFromPort( port ); 
  if ( w ) 
  { 
  brush = (long)( inBackRGB ); 
  if ( (-(brush >= kThemeBrushAlternatePrimaryHighlightColor)) & (-(brush <= kThemeBrushMenuBackgroundSelected)) ) 
  { 
  SetThemeWindowBackground( w, brush, applyNow ); 
  } 
  else 
  { 
  if ( inBackRGB ) 
  { 
  backRGB = (void*)inBackRGB; 
  RGBBackColor( backRGB ); 
  SetWindowContentColor( w, backRGB ); 
  if ( applyNow ) 
  { 
  Cls();   } 
  } 
  } 
  } 
  } 
}  
  
 
void  InvalRect( Rect * r ) 
{
  CGrafPtr          port; 
  WindowRef         wnd; 
  GetPort( (void*)&port ); 
  wnd = GetWindowFromPort( port ); 
  InvalWindowRect( wnd, r ); 
}  
  
 
void  NewWindowPositionMethod( WindowPositionMethod pMethod ) 
{
 
  gSelectL[1] = pMethod; 
  if ( gSelectL[1] == 0 || gSelectL[1] == kWindowCenterOnMainScreen || gSelectL[1] == kWindowCascadeOnMainScreen || gSelectL[1] == kWindowAlertPositionOnMainScreen ) 
  { 
  gNewWndPositionMethod = pMethod; 
  } 
  else  { 
  (gFBTStkP = 0, RuntimeErrMsg( PSstrcpy( gFBTStk[++gFBTStkP], "\pdef NewWindowPositionMethod must set 0, _kWindowCenterOnMainScreen, _kWindowCascadeOnMainScreen, or _kWindowAlertPositionOnMainScreen" ) )); 
  } 
 
}  
  
 
 
void  WindowReposition( long wNum, long parentWNum, WindowPositionMethod pMethod ) 
{
  WindowRef         w; 
  WindowRef         wParent; 
  if ( (-(pMethod < kWindowCenterOnMainScreen)) | (-(pMethod > kWindowAlertPositionOnParentWindowScreen)) ) 
  { 
  (gFBTStkP = 0, RuntimeErrMsg( (PSstrcpy( gFBTStk[++gFBTStkP], "\pBad method parameter in def WindowReposition for window" ), PSstrcat( gFBTStk[gFBTStkP], PSstr( wNum ) )) )); 
  goto LL10; 
  } 
  FBGetWindow( wNum, &w ); 
  if ( w == 0 ) 
  { 
  (gFBTStkP = 0, RuntimeErrMsg( (PSstrcpy( gFBTStk[++gFBTStkP], "\pBad wNum parameter in def WindowReposition: " ), PSstrcat( gFBTStk[gFBTStkP], PSstr( wNum ) )) )); 
  goto LL10; 
  } 
 
  gSelectL[1] = pMethod; 
  if ( gSelectL[1] == kWindowCenterOnMainScreen || gSelectL[1] == kWindowCascadeOnMainScreen || gSelectL[1] == kWindowAlertPositionOnMainScreen ) 
  { 
  RepositionWindow( w, NULL, pMethod ); 
  } 
  else  { 
  FBGetWindow( parentWNum, &wParent ); 
  if ( wParent ) 
  { 
  RepositionWindow( w, wParent, pMethod ); 
  } 
  else 
  { 
  (gFBTStkP = 0, RuntimeErrMsg( (PSstrcpy( gFBTStk[++gFBTStkP], "\pBad parentWNum parameter in def WindowReposition for window" ), PSstrcat( gFBTStk[gFBTStkP], PSstr( wNum ) )) )); 
  } 
  } 
 
LL10:; 
}  
  
 
 
void  WindowCategory( long wNum, long wCategory ) 
{
  WindowRef         w; 
  FBGetWindow( wNum, &w ); 
  if ( w ) 
  { 
  SetWindowProperty( w, 0, 2000904564, sizeof( long ), (void*)&wCategory ); 
  } 
}  
  

